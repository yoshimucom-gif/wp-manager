<?php
/**
 * カテゴリのチェックリスト描画（親子構造つき）
 *
 * v1.0.29: 装飾・整形の両方の一括画面が同じフラット一覧をコピペで持っていたため、
 * ここに集約する。片方だけ直して噛み合わなくなる事故を構造的に防ぐ（1.0.21 と同じ方針）。
 *
 * 表示の考え方:
 *   - 親→子の順に並べ、深さぶんインデントする
 *   - 親を選ぶと配下の子も対象になる（WP_Query の tax_query は include_children が既定 true）。
 *     そのため親が選ばれている間、子は「親で選択済み」として無効化する。実挙動と表示を一致させる。
 *   - 親の (N) はその親に直接ぶら下がる記事数。子を含めた総数は「配下計」として別に出す。
 */

if (!defined('ABSPATH')) exit;

/**
 * カテゴリのチェックリストを出力する。
 *
 * @param array $args input_class / list_id
 */
function decofmt_render_category_checklist($args = []) {
    $args = wp_parse_args($args, [
        'input_class' => 'decofmt-cat',
        'list_id'     => '',
    ]);

    $cats = get_categories(['hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC']);
    if (empty($cats)) {
        echo '<p class="description">カテゴリがありません。</p>';
        return;
    }

    $by_id = [];
    foreach ($cats as $c) {
        $by_id[(int) $c->term_id] = $c;
    }

    // 親が取得結果に無いターム（権限や絞り込みで欠けた場合）はルート扱いにして取りこぼさない
    $children = [];
    foreach ($cats as $c) {
        $parent = (int) $c->parent;
        if ($parent && !isset($by_id[$parent])) $parent = 0;
        $children[$parent][] = $c;
    }

    $totals = [];
    foreach (array_keys($by_id) as $tid) {
        $totals[$tid] = decofmt_term_subtree_count($children, $by_id, $tid);
    }

    $id_attr = $args['list_id'] ? ' id="' . esc_attr($args['list_id']) . '"' : '';
    echo '<div class="decofmt-checkbox-list decofmt-term-tree"' . $id_attr . '>';
    decofmt_render_category_branch($children, $totals, 0, 0, $args['input_class']);
    echo '</div>';
}

/**
 * 自分＋配下すべての記事数の合計。
 * 親子ループが仕込まれていても止まるよう、たどった term を控えておく。
 */
function decofmt_term_subtree_count($children, $by_id, $term_id, $seen = []) {
    $term_id = (int) $term_id;
    if (isset($seen[$term_id]) || !isset($by_id[$term_id])) return 0;
    $seen[$term_id] = true;

    $sum = (int) $by_id[$term_id]->count;
    if (!empty($children[$term_id])) {
        foreach ($children[$term_id] as $child) {
            $sum += decofmt_term_subtree_count($children, $by_id, $child->term_id, $seen);
        }
    }
    return $sum;
}

/**
 * 1階層ぶんのラベルを出して、子があれば再帰する。
 */
function decofmt_render_category_branch($children, $totals, $parent, $depth, $input_class) {
    if ($depth > 10 || empty($children[$parent])) return;

    foreach ($children[$parent] as $cat) {
        $tid      = (int) $cat->term_id;
        $has_kids = !empty($children[$tid]);
        $total    = isset($totals[$tid]) ? (int) $totals[$tid] : (int) $cat->count;

        printf(
            '<label class="decofmt-term-item%1$s" style="--decofmt-depth:%2$d" data-term="%3$d" data-parent="%4$d" data-depth="%2$d">'
                . '<input type="checkbox" class="%5$s" value="%3$d">'
                . '<span class="decofmt-term-name">%6$s</span>'
                . '<span class="decofmt-count">(%7$d)</span>',
            $has_kids ? ' has-children' : '',
            (int) $depth,
            $tid,
            (int) $parent,
            esc_attr($input_class),
            esc_html($cat->name),
            (int) $cat->count
        );

        if ($has_kids) {
            printf('<span class="decofmt-count-sub">配下計 %d</span>', $total);
        }

        echo '<span class="decofmt-term-covered">親で選択済み</span></label>';

        decofmt_render_category_branch($children, $totals, $tid, $depth + 1, $input_class);
    }
}
