<?php
/**
 * プラグイン自動更新チェッカー
 *
 * ミカタOWNED（mikata-owned.onrender.com）を WordPress の更新サーバーとして使い、
 * 標準の「プラグイン更新」フローに組み込む。
 *
 * 動作:
 *   1. WP が定期的に pre_set_site_transient_update_plugins を叩く
 *   2. 本クラスがミカタOWNED から JSON を取得し、ヘッダーバージョンと比較
 *   3. 新しければ transient->response に追加 → 「更新可能」バッジ表示
 *   4. ユーザーが「更新」クリック → WP が download_url から zip 取得・展開
 *
 * 更新サーバーのURLは `DECOFMT_UPDATE_HOST` 定数で上書き可能（wp-config.php等で設定）。
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('Decofmt_Plugin_Updater')) :

class Decofmt_Plugin_Updater {
    /** プラグイン本体ファイル (__FILE__) */
    private $plugin_file;
    /** プラグインスラッグ (ディレクトリ名) */
    private $plugin_slug;
    /** プラグインベース名 (例: decoration-formatter/decoration-formatter.php) */
    private $plugin_basename;
    /** アップデート情報エンドポイント URL */
    private $update_url;
    /** リモート情報キャッシュキー */
    private $cache_key;
    /** リモート情報キャッシュ TTL (秒) */
    private $cache_ttl;
    /** スラッグ => インスタンス（設定画面から強制チェックを呼ぶため） */
    private static $instances = [];

    /** スラッグからインスタンスを取り出す */
    public static function get($slug) {
        return isset(self::$instances[$slug]) ? self::$instances[$slug] : null;
    }

    public function __construct($plugin_file, $update_url, $cache_ttl = 1800) {
        $this->plugin_file     = $plugin_file;
        $this->plugin_basename = plugin_basename($plugin_file);
        $this->plugin_slug     = dirname($this->plugin_basename);
        $this->update_url      = $update_url;
        $this->cache_key       = 'decofmt_updater_' . md5($this->plugin_basename);
        $this->cache_ttl       = (int)$cache_ttl;

        self::$instances[$this->plugin_slug] = $this;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_update']);
        add_filter('plugins_api',                            [$this, 'plugins_api_filter'], 10, 3);
        add_action('upgrader_process_complete',              [$this, 'purge_cache'], 10, 2);
    }

    /** 直近の取得結果（成功／失敗）。設定画面の診断表示に使う */
    private $last_error = '';

    /** サーバーから最新メタ情報を取得（キャッシュあり） */
    private function fetch_remote_info($force = false) {
        if ($force) {
            delete_transient($this->cache_key);
        } else {
            $cached = get_transient($this->cache_key);
            // v1.0.29: 失敗も短期間キャッシュする。取れないたびに毎回待たされて
            //   管理画面が重くなる（＝更新チェックが黙って死ぬ）のを防ぐ。
            if ($cached === 'decofmt_fetch_failed') return null;
            if ($cached !== false) return $cached;
        }

        // v1.0.29: 10秒だと更新サーバー(Render)がスリープから起きる間に切れて
        //   「更新通知が出ない」状態になっていた。起床待ちを見込んで20秒にする。
        $response = wp_remote_get($this->update_url, [
            'timeout' => 20,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            $this->last_error = $response->get_error_message();
        } elseif ((int)wp_remote_retrieve_response_code($response) !== 200) {
            $this->last_error = 'HTTP ' . (int)wp_remote_retrieve_response_code($response);
        } else {
            $data = json_decode(wp_remote_retrieve_body($response));
            if (is_object($data) && !empty($data->version)) {
                set_transient($this->cache_key, $data, $this->cache_ttl);
                $this->last_error = '';
                return $data;
            }
            $this->last_error = '応答が JSON として読めませんでした';
        }

        set_transient($this->cache_key, 'decofmt_fetch_failed', 5 * MINUTE_IN_SECONDS);
        return null;
    }

    /**
     * v1.0.29: 更新チェックを今すぐやり直す。
     *
     * プラグイン側のキャッシュだけ消しても、WP 本体は update_plugins サイトトランジェント
     * （最大12時間）を見ているのでバッジが出ない。両方消してから再チェックさせる。
     *
     * @return array [installed, remote, error]
     */
    public function force_check() {
        $remote = $this->fetch_remote_info(true);

        delete_site_transient('update_plugins');
        if (function_exists('wp_update_plugins')) wp_update_plugins();

        return [
            'installed' => $this->current_installed_version(),
            'remote'    => $remote && !empty($remote->version) ? $remote->version : '',
            'error'     => $this->last_error,
        ];
    }

    /** WP の更新チェックに割り込んで、自分の更新情報を注入する */
    public function check_for_update($transient) {
        if (!is_object($transient)) return $transient;

        $remote = $this->fetch_remote_info();
        if (!$remote) return $transient;

        $current_version = $this->current_installed_version();
        if (!$current_version) return $transient;

        if (version_compare($current_version, $remote->version, '<')) {
            $entry = (object)[
                'id'           => $this->plugin_basename,
                'slug'         => $this->plugin_slug,
                'plugin'       => $this->plugin_basename,
                'new_version'  => $remote->version,
                'url'          => isset($remote->homepage) ? $remote->homepage : '',
                'package'      => isset($remote->download_url) ? $remote->download_url : '',
                'tested'       => isset($remote->tested) ? $remote->tested : '',
                'requires'     => isset($remote->requires) ? $remote->requires : '',
                'requires_php' => isset($remote->requires_php) ? $remote->requires_php : '',
                'icons'        => [],
                'banners'      => [],
            ];
            if (!isset($transient->response) || !is_array($transient->response)) {
                $transient->response = [];
            }
            $transient->response[$this->plugin_basename] = $entry;
        } else {
            // 最新だが no_update に登録しておくと UI が "最新" 表示になる
            if (!isset($transient->no_update) || !is_array($transient->no_update)) {
                $transient->no_update = [];
            }
            $transient->no_update[$this->plugin_basename] = (object)[
                'id'          => $this->plugin_basename,
                'slug'        => $this->plugin_slug,
                'plugin'      => $this->plugin_basename,
                'new_version' => $remote->version,
                'url'         => '',
                'package'     => '',
            ];
        }
        return $transient;
    }

    /** 「詳細を表示」モーダル用 */
    public function plugins_api_filter($result, $action, $args) {
        if ($action !== 'plugin_information') return $result;
        if (!isset($args->slug) || $args->slug !== $this->plugin_slug) return $result;

        $remote = $this->fetch_remote_info();
        if (!$remote) return $result;

        return (object)[
            'name'         => isset($remote->name) ? $remote->name : $this->plugin_slug,
            'slug'         => $this->plugin_slug,
            'version'      => $remote->version,
            'tested'       => isset($remote->tested) ? $remote->tested : '',
            'requires'     => isset($remote->requires) ? $remote->requires : '',
            'requires_php' => isset($remote->requires_php) ? $remote->requires_php : '',
            'author'       => isset($remote->author) ? $remote->author : '',
            'download_link'=> isset($remote->download_url) ? $remote->download_url : '',
            'sections'     => isset($remote->sections) ? (array)$remote->sections : [],
            'banners'      => [],
        ];
    }

    /** 更新完了後にキャッシュを破棄して再チェックを促す */
    public function purge_cache($upgrader, $hook_extra) {
        if (!is_array($hook_extra)) return;
        if (($hook_extra['action'] ?? '') !== 'update') return;
        if (($hook_extra['type']   ?? '') !== 'plugin') return;
        delete_transient($this->cache_key);
    }

    /** 現在インストール済みのバージョン（プラグインヘッダー）を取得 */
    private function current_installed_version() {
        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $data = get_plugin_data($this->plugin_file, false, false);
        return isset($data['Version']) ? $data['Version'] : '';
    }
}

endif;
