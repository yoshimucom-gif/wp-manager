<?php
/**
 * Plugin Name: Affiros ポストプロセッサー
 * Description: Affiros9 で生成した記事の後工程を全部やる統合ツール。Claude API リライト / 商品カード・マーカーの削除&挿入 / H2 章の並び替え / 段落整形。WP_Query 内部処理でホスティング WAF の影響を受けない（403 回避）。
 * Version: 0.5.9
 * Author: Affiros
 * License: GPL v2 or later
 * Text Domain: affiros-rewrite
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AFFIROS_REWRITE_VERSION', '0.5.9');
define('AFFIROS_REWRITE_PATH', plugin_dir_path(__FILE__));
define('AFFIROS_REWRITE_URL', plugin_dir_url(__FILE__));

// オプションキー
define('AFFIROS_REWRITE_OPTION_KEY', 'affiros_rewrite_settings');

// モジュール読み込み
require_once AFFIROS_REWRITE_PATH . 'includes/claude-api.php';
require_once AFFIROS_REWRITE_PATH . 'includes/post-fetcher.php';
require_once AFFIROS_REWRITE_PATH . 'includes/marker-inserter.php';
require_once AFFIROS_REWRITE_PATH . 'includes/marker-validator.php';
require_once AFFIROS_REWRITE_PATH . 'includes/article-type.php';
require_once AFFIROS_REWRITE_PATH . 'includes/heading-sanitizer.php';
require_once AFFIROS_REWRITE_PATH . 'includes/rewrite-engine.php';
require_once AFFIROS_REWRITE_PATH . 'includes/gutenberg-converter.php';
require_once AFFIROS_REWRITE_PATH . 'includes/pre-cleanup.php';
require_once AFFIROS_REWRITE_PATH . 'includes/section-reorder.php';
require_once AFFIROS_REWRITE_PATH . 'includes/revision-restorer.php';
// v0.5.0: 旧独立プラグイン affiros-paragraph-splitter を統合。
// 旧プラグインが有効な環境では自動でスキップして共存する（読み込み側の guard 参照）。
require_once AFFIROS_REWRITE_PATH . 'includes/paragraph-splitter.php';
require_once AFFIROS_REWRITE_PATH . 'includes/plugin-updater.php';
require_once AFFIROS_REWRITE_PATH . 'admin/settings-page.php';
require_once AFFIROS_REWRITE_PATH . 'admin/rewrite-page.php';
require_once AFFIROS_REWRITE_PATH . 'admin/restore-page.php';
require_once AFFIROS_REWRITE_PATH . 'admin/table-repair-page.php';
require_once AFFIROS_REWRITE_PATH . 'admin/duplicate-cleanup-page.php';
require_once AFFIROS_REWRITE_PATH . 'admin/ajax-handler.php';

/**
 * Affiros9 サーバーをアップデートサーバーとして登録。
 * これ以降の更新は WP 管理画面の「プラグイン」から「今すぐ更新」で行える。
 *
 * 別ホストで運用する場合は wp-config.php に
 *   define('AFFIROS_UPDATE_HOST', 'https://your-host.example.com');
 * を入れると自動で切り替わる。
 */
add_action('init', function () {
    $host = defined('AFFIROS_UPDATE_HOST') ? AFFIROS_UPDATE_HOST : 'https://wp-manager.onrender.com';
    new Affiros_Plugin_Updater(__FILE__, rtrim($host, '/') . '/api/plugin-update/rewrite');
});

/**
 * デフォルト設定
 */
function affiros_rewrite_default_settings() {
    return [
        'claude_api_key' => '',
        'claude_model' => 'claude-sonnet-4-6',
        'rewrite_mode' => 'seo',          // seo / readability / freshness
        'emphasis_level' => 'standard',   // light / standard / strong
        'tone' => 'natural',              // natural / professional / casual
        'target_chars' => 0,              // 0 = 元記事に合わせる
        'tolerance_percent' => 10,
        'ad_patterns' => [],              // 広告挿入定義（空=デフォルトパターン使用）
    ];
}

/**
 * 旧モデルID → 現行モデルID のマイグレーションマップ
 *
 * v0.3.0 以前を入れていた環境は DB に旧モデルIDが保存されたままになる。
 * 旧IDのまま API を叩くとリタイア済みモデルで失敗するため、設定読み込み時に
 * 現行IDへ寄せる。
 */
function affiros_rewrite_migrate_model_id($model) {
    $map = [
        'claude-sonnet-4-5-20250929' => 'claude-sonnet-4-6',
        'claude-sonnet-4-5'          => 'claude-sonnet-4-6',
        'claude-opus-4-1-20250805'   => 'claude-opus-4-7',
        'claude-opus-4-1'            => 'claude-opus-4-7',
        'claude-3-5-haiku-20241022'  => 'claude-haiku-4-5-20251001',
        'claude-3-5-haiku'           => 'claude-haiku-4-5-20251001',
        'claude-haiku-4-5'           => 'claude-haiku-4-5-20251001',
    ];
    return $map[$model] ?? $model;
}

/**
 * 設定取得
 */
function affiros_rewrite_get_settings() {
    $saved = get_option(AFFIROS_REWRITE_OPTION_KEY, []);
    $settings = array_merge(affiros_rewrite_default_settings(), is_array($saved) ? $saved : []);
    $settings['claude_model'] = affiros_rewrite_migrate_model_id($settings['claude_model'] ?? '');

    // wp-config.php に AFFIROS_REWRITE_API_KEY を定義していれば最優先で使う。
    // wp-config.php はプラグインの更新・再インストール・削除で変更されないため、
    // この方式ならAPIキーが消えることはない。
    if (defined('AFFIROS_REWRITE_API_KEY') && AFFIROS_REWRITE_API_KEY) {
        $settings['claude_api_key'] = AFFIROS_REWRITE_API_KEY;
    }
    return $settings;
}

/**
 * v0.5.9: 段落整形の独立ページ。旧 rewrite-page.php 内のタブ埋め込みを
 *   撤廃したため、専用ページに切り分けた。中身は既存の render_tab_body を
 *   `<div class="wrap"><h1>...</h1>` で包むだけ。
 */
function affiros_rewrite_render_psplit_page() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div class="wrap affiros-wrap">
        <h1>📝 Affiros 段落整形</h1>
        <?php
        if (function_exists('affiros_psplit_render_tab_body')) {
            try {
                affiros_psplit_render_tab_body();
            } catch (\Throwable $e) {
                echo '<div class="notice notice-error"><p><strong>段落整形モジュールでエラー:</strong> ' . esc_html($e->getMessage()) . '</p></div>';
            }
        } else {
            echo '<div class="notice notice-error"><p>段落整形モジュールが読み込まれていません。プラグインファイルの再インストールをお試しください。</p></div>';
        }
        ?>
    </div>
    <?php
}

/**
 * 管理メニュー登録
 */
add_action('admin_menu', function () {
    // v0.5.2: メニューラベル「Affiros リライト」→「Affiros ポストプロセッサー」に改称。
    // v0.5.3: 全サブメニューに絵文字統一 + 使用頻度順に並び替え
    //   毎日  → 記事整備 (メインの4タブ画面)
    //   時々  → 重複投稿削除
    //   稀    → リビジョン復元 / テーブル修復 (緊急時のみ)
    //   初期  → 設定
    add_menu_page(
        'Affiros ポストプロセッサー',
        'Affiros ポストプロセッサー',
        'manage_options',
        'affiros-rewrite',
        'affiros_rewrite_render_rewrite_page',
        'dashicons-edit',
        76
    );
    add_submenu_page(
        'affiros-rewrite',
        'ポストプロセッサー',
        '✏️ 記事整備',
        'manage_options',
        'affiros-rewrite',
        'affiros_rewrite_render_rewrite_page'
    );
    // v0.5.9: 段落整形は別ページに分離（旧 rewrite-page.php 内タブ埋め込みは撤廃）
    add_submenu_page(
        'affiros-rewrite',
        '段落整形',
        '📝 段落整形',
        'manage_options',
        'affiros-rewrite-psplit',
        'affiros_rewrite_render_psplit_page'
    );
    add_submenu_page(
        'affiros-rewrite',
        '重複投稿クリーンアップ',
        '📦 重複投稿削除',
        'manage_options',
        'affiros-rewrite-dup-cleanup',
        'affiros_rewrite_render_duplicate_cleanup_page'
    );
    add_submenu_page(
        'affiros-rewrite',
        'リビジョン復元',
        '⏮ リビジョン復元',
        'manage_options',
        'affiros-rewrite-restore',
        'affiros_rewrite_render_restore_page'
    );
    add_submenu_page(
        'affiros-rewrite',
        'テーブル修復',
        '🔧 テーブル修復',
        'manage_options',
        'affiros-rewrite-table-repair',
        'affiros_rewrite_render_table_repair_page'
    );
    add_submenu_page(
        'affiros-rewrite',
        '設定',
        '⚙️ 設定',
        'manage_options',
        'affiros-rewrite-settings',
        'affiros_rewrite_render_settings_page'
    );
});

/**
 * 管理画面用 CSS/JS
 */
add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos($hook, 'affiros-rewrite') === false) {
        return;
    }
    wp_enqueue_style(
        'affiros-rewrite-admin',
        AFFIROS_REWRITE_URL . 'assets/admin.css',
        [],
        AFFIROS_REWRITE_VERSION
    );
    // 画面のJSは各ページにインラインで持たせている。ajax 用の値だけ jQuery 経由で渡す。
    wp_localize_script('jquery', 'AffirosRewrite', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('affiros_rewrite_nonce'),
    ]);
});

/**
 * 有効化フック
 */
register_activation_hook(__FILE__, function () {
    if (!get_option(AFFIROS_REWRITE_OPTION_KEY)) {
        update_option(AFFIROS_REWRITE_OPTION_KEY, affiros_rewrite_default_settings());
    }
});
