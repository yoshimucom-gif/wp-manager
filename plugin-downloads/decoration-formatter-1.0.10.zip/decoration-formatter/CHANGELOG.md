# 変更履歴

装飾・整形プラグイン（`decoration-formatter`）の改修履歴です。

> **引き継ぎメモ**
> 別のチャット／担当者に作業を引き継ぐときは、まず `README.md`（機能概要）と
> このファイル（改修履歴）を読んでください。各エントリには変更したファイル名を
> 併記しているので、コードのどこを触ったか追跡できます。
> このプラグインはバージョン管理（git）下になく、配布zipが唯一の成果物です。

フォーマットは [Keep a Changelog](https://keepachangelog.com/ja/1.1.0/) に準拠し、
バージョンは [セマンティック バージョニング](https://semver.org/lang/ja/) に従います。

---

## [1.0.10] - 2026-07-09

### 修正（バグ）
- **`<!-- wp:paragraph -->` の2重wrapping**（Gutenberg「無効なコンテンツ」エラー）を修正。
  `add_heading_spacing` / `add_media_spacing` が H2/画像/表の前に
  `<!-- wp:paragraph --><p></p><!-- /wp:paragraph -->` を挿入していたが、
  後段の「全 `<p>` を wp:paragraph でラップ」で内側の `<p></p>` が2重に包まれて
  `<!-- wp:paragraph --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- /wp:paragraph -->`
  という nested 構造を生成していた。
  - **修正**: 挿入時は素の `<p></p>` のみ。後段のラップ処理で1回だけ包まれる。
  - — `includes/paragraph-formatter.php`

**⚠️ 既に壊れた記事**: WPリビジョン（投稿編集画面 → 右サイドバー → リビジョン）から
分割前の版に戻すのが安全。または Gutenberg 側の「復旧を試みる」ボタンで自動修復も可能な場合あり。

---

## [1.0.9] - 2026-07-09

### 修正（バグ）
- **リンク `<a>` 等のタグ内で句点分割すると HTML が壊れる問題を修正**
  （Gutenberg「無効なコンテンツ」の原因）。`<a href="...">B。C</a>` のようにタグ内テキストに
  句点があると、`<a>` と `</a>` が別セグメントに跨いで壊れていた。
  - **修正**: `split_inner` の分割後、各セグメントのタグ開閉バランスをチェックし、
    アンバランスなら次のセグメントと結合。結果、タグ内の句点では実質的に分割しない。
  - void要素（`<br>`, `<img>` 等）はカウント対象外。
  - v1.0.8で導入した「1文ごとに改行」モードが本質的にこの問題を露出させた
    （通常モードでも同じバグ潜在だったが、閾値で回避されていた）。
  - — `includes/paragraph-formatter.php`

**⚠️ 既に壊れた記事の復旧**: WPリビジョン（投稿編集画面 → 右サイドバー → リビジョン）から
分割前の版に戻すのが安全。v1.0.9では自動復旧はしません（データ保全のため）。

---

## [1.0.8] - 2026-07-09

### 追加
- **「1文ごとに改行する」モードを追加**。設定画面の段落整形に新チェックボックス（既定オフ）。
  オンにすると、句点（。！？）2個以上の段落を字数閾値・接続詞・min_sentence_chars を無視して
  **全部句点で分割**。会話体・箇条書きベースの記事向け。
  - 処理・スキャン・counterすべてに反映（process_content と stats のロジック対称）
  - `includes/paragraph-formatter.php` / `admin/settings.php`

---

## [1.0.7] - 2026-07-09

### 修正（バグ）
- **「11件検出→変換2件、残9件」の非対称バグを解消**。v1.0.6で追加した multi_sentence_short
  counter は「3句以上あるか」だけを見ていたが、`split_inner` が各セグメント `min_sentence_chars=60`
  以上を要求するため、90字/3句のような段落はセグメント吸収されて1セグメントに戻り「検出はするが分割されない」
  状態だった（strong_label_candidates で以前起こした off-by-one と同じ性質）。
  - **`process_content`**: 3+句短段落が `split_inner` の壁で1セグメントに吸収された場合、
    `min_sentence_chars=1` で強制リトライ（句点ごとに確実に分割）を追加
  - **`stats`**: counter で `split_inner` を実際に呼んで「本当に≥2セグメント返すか」を確認してから
    カウント。**counter = 実際の変換数**、を保証
  - 60字未満の3句パラ（例: 「はい。ええ。それで。」）は分割意義がないので候補から除外
  - — `includes/paragraph-formatter.php`

---

## [1.0.6] - 2026-07-09

### 修正（バグ）
- **「短めだが句点3個以上」の密な段落を分割対象化**（処理・スキャン・UI・delta 全ラインを一括対応）。
  従来は `min_paragraph_chars`（既定200字）以下の段落は一律「短いのでスキップ」だったが、
  これだと **192字/4句** のような閾値ギリギリで密な段落が放置されていた。
  新ルール: **字数条件 OR 句点3個以上** の段落を分割対象に。
  短くて実際に割れないケースは `split_inner` の `min_sentence_chars` で吸収されるため、
  過剰分割は起きない。
  - `includes/paragraph-formatter.php` — `process_content` の判定と `stats` の
    `multi_sentence_short` カウンタ追加
  - `admin/ajax-handler.php` — スキャンの対象判定と apply の delta 計算に反映
  - `admin/formatter-bulk.php` — 一括処理表に「3句以上短段落」列追加、delta 合計計算に反映
  - `admin/formatter-meta-box.php` — 投稿編集画面のメタボックスに表示追加

---

## [1.0.4] - 2026-07-09

### 追加
- **プラグイン自動更新機能を再導入。** WordPress の標準プラグイン更新フローに組み込み、
  ミカタOWNED（`mikata-owned.onrender.com`）を更新サーバーとして参照。
  管理画面「プラグイン」画面で「更新可能」バッジ→クリックで自動アップグレード可能に。
  更新サーバーURLは `DECOFMT_UPDATE_HOST` 定数で上書き可能（`wp-config.php` で設定）。
  — `includes/plugin-updater.php`（新規） / `decoration-formatter.php`

これに伴い、以後の更新は各WPサイトで **プラグイン画面 → 更新** で完結。手動zipアップロードは不要。
（初回のみ手動でこの v1.0.4 のzipをインストールする必要があります）

---

## [1.0.3] - 2026-07-09

旧 `affiros-paragraph-splitter` v1.1.2 / v1.1.3 のバグ修正・改善を移植。
（v1.1.4 の統合ガードは Affiros 内部再編用のためスキップ）

### 修正（バグ）
- **strongラベル `<li>` パターンのカウント漏れ** — `<li><strong>ラベル</strong>：長文</li>` の合計 plain text が `heading_max_chars`（既定60字）を超える場合、従来は SKIP されて「整形対象0件」と誤表示されていた。stats に `strong_label_candidates` を独立カウンタとして追加し、正しく検出するように修正。 — `includes/paragraph-formatter.php`
- **off-by-one 修正** — strong+コロン `<li>` 分割の閾値判定を `mb_strlen > min_content` から `>= min_content` に修正。stats 側と条件を揃えることで、境界の1件が「検出はする、分割しない」ループにハマる不具合を解消。 — `includes/paragraph-formatter.php`

### 改善
- **適用結果に delta stats を追加** — 段落整形 apply エンドポイントが `over_200_resolved` / `heading_promoted` / `strong_label_split` を返すように変更。「27件処理したが実変換は3件」といった実態が可視化される。 — `admin/ajax-handler.php`
- **一括適用のサマリを詳細化** — 「実変換 N件 / 変換なし M件 / 失敗 X件」と、検出済みパターンが残る記事数も表示。 — `admin/formatter-bulk.php`
- **一括適用後に自動再スキャン** — 従来は表がそのまま残り「27件成功したのにまだ27件ある」ように見えていた問題を解消。 — `admin/formatter-bulk.php`
- 一括処理表とメタボックスに「strongラベル」列/行を追加。 — `admin/formatter-bulk.php` / `admin/formatter-meta-box.php`
- 段落整形スキャンの対象判定に `strong_label_candidates` を追加。 — `admin/ajax-handler.php`

---

## [1.0.2] - 2026-07-09

### 修正（バグ）
- **段落整形一括画面の「全記事スキャン」で「通信エラー: -1」が発生する問題を修正。**
  インラインJSがIIFE実行時（body描画時）に `decofmt.nonce` を捕捉しようとしていたが、
  `wp_localize_script` はフッターで出力されるためこの時点で `decofmt` グローバルは未定義。
  結果 nonce が空文字になり、WordPressが `-1`（nonce認証失敗）を返していた。
  クリック時に nonce を再評価する関数化に変更。— `admin/formatter-bulk.php`
- WP からの `-1` レスポンスを明示的に検出して、原因を含んだメッセージを表示するよう改善。
  併せて通信エラー時に HTTP ステータスとレスポンス本文を表示。 — `admin/formatter-bulk.php` / `admin/formatter-meta-box.php`

---

## [1.0.1] - 2026-07-09

### 改善
- 設定画面の Claude APIキー入力欄に「👁 表示」チェックボックスを追加。既定はマスク表示（●●●●）、チェックで平文表示に切り替え。入力ミスの確認用。 — `admin/settings.php`

---

## [1.0.0] - 2026-07-07

### 追加（初版・統合）
以下の2つの独立プラグインを統合し、Affirosブランドを除去した汎用プラグインとして再構成した初版。
DBPテーマ用ブロック生成前提は継続。自動更新機能（Affiros9サーバー参照）は削除。

**AI装飾（旧 `affiros-decoration` v1.2.1 由来）**
- Claude API による記事本文の自動装飾（マーカー・赤字・強調ボックス・アイコンリスト等）
- 装飾レベル3段階（軽め/標準/盛り盛り）、モデル4種選択可
- ロールバック機能（自動バックアップ）
- バリデーション（ブロック構文・文字数比較・H2保持）
- 検証エラー時にモデルへエラー内容をフィードバックして自動リトライ
- 絞り込み一括処理（カテゴリ・タグ・装飾状況）
- 処理ログ＋モデル別集計＋ログ全削除ボタン
- 個別記事の除外フラグ

**段落整形（旧 `affiros-paragraph-splitter` v1.1.1 由来）**
- 長段落の分割（句点・接続詞・強制分割しきい値）
- 句読点連続の正規化
- 見出し昇格（正規表現パターン + 文字数閾値）
- リスト内 `<strong>ラベル</strong>：長文` の見出し+段落分解（親見出しレベル+1で階層化）
- H2/H3・画像・表前後の空段落挿入
- 全記事スキャン→ before/afterプレビュー→ 個別/一括適用
- 保存時自動整形オプション

### 変更（統合に伴う内部リファクタ）
- ディレクトリ・スラッグ: `decoration-formatter`
- 全定数・関数プレフィックスを新体系に統一
  - 定数: `DECOFMT_*`（VERSION, PATH, URL）
  - 装飾側関数: `decofmt_deco_*` / クラス `Decofmt_*`
  - 整形側関数: `decofmt_fmt_*`
  - オプションキー: `decofmt_deco_settings` / `decofmt_fmt_settings`（分離保持）
  - 投稿メタ: `_decofmt_*`
  - AJAX nonce: `decofmt_nonce`（統一）
  - AJAXアクション: `decofmt_deco_*` / `decofmt_fmt_*`
- 管理画面をトップメニュー「装飾・整形」1本に統合
  - 設定（統合画面・2フォーム）／ AI装飾（一括）／ 段落整形（一括）／ 処理ログ
- 投稿編集画面のサイドバーに両方のメタボックスを表示（🎨 AI装飾 / 📝 段落整形）
- 統合設定画面：AI装飾と段落整形を1画面2フォームで管理

### 削除
- **自動更新機能（`affiros-paragraph-splitter` の `includes/plugin-updater.php`）** を削除
  - Affiros9 サーバー（wp-manager.onrender.com）依存を排除
  - 更新は zip の手動アップロード運用に統一

---

_2つの元プラグインの詳細な履歴は、それぞれの旧 zip 内 CHANGELOG を参照。_
