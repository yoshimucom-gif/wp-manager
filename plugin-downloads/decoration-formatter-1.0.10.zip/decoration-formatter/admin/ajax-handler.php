<?php
/**
 * AJAX処理ハンドラ（装飾 + 整形）
 *
 * 装飾: decofmt_deco_* アクション
 * 整形: decofmt_fmt_* アクション
 * nonce は両方共通の 'decofmt_nonce'
 */

if (!defined('ABSPATH')) exit;

// =============================================================================
// AI装飾 AJAX
// =============================================================================

add_action('wp_ajax_decofmt_deco_decorate', 'decofmt_deco_ajax_decorate');
function decofmt_deco_ajax_decorate() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => '権限がありません']);
    }

    $post_id = intval($_POST['post_id'] ?? 0);
    $dry_run = ($_POST['dry_run'] ?? 'false') === 'true';
    $level = sanitize_text_field($_POST['level'] ?? '');
    $model = sanitize_text_field($_POST['model'] ?? '');

    if (!$post_id) {
        wp_send_json_error(['message' => '記事IDが不正です']);
    }

    $allowed_models = array_keys(decofmt_get_models());
    if ($model && !in_array($model, $allowed_models, true)) {
        $model = '';
    }

    $options = ['dry_run' => $dry_run];
    if ($level) $options['level'] = $level;
    if ($model) $options['model'] = $model;

    $result = Decofmt_Decorator::decorate_post($post_id, $options);

    if (is_wp_error($result)) {
        wp_send_json_error(['message' => $result->get_error_message()]);
    }

    wp_send_json_success($result);
}

add_action('wp_ajax_decofmt_deco_rollback', 'decofmt_deco_ajax_rollback');
function decofmt_deco_ajax_rollback() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => '権限がありません']);
    }

    $post_id = intval($_POST['post_id'] ?? 0);
    if (!$post_id) {
        wp_send_json_error(['message' => '記事IDが不正です']);
    }

    $result = Decofmt_Decorator::rollback_post($post_id);

    if (is_wp_error($result)) {
        wp_send_json_error(['message' => $result->get_error_message()]);
    }

    wp_send_json_success($result);
}

add_action('wp_ajax_decofmt_deco_toggle_exclude', 'decofmt_deco_ajax_toggle_exclude');
function decofmt_deco_ajax_toggle_exclude() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => '権限がありません']);
    }

    $post_id = intval($_POST['post_id'] ?? 0);
    $excluded = ($_POST['excluded'] ?? 'false') === 'true';

    Decofmt_Post_Meta::set_excluded($post_id, $excluded);
    wp_send_json_success(['excluded' => $excluded]);
}

add_action('wp_ajax_decofmt_deco_count_targets', 'decofmt_deco_ajax_count_targets');
function decofmt_deco_ajax_count_targets() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => '権限がありません']);
    }

    $args = [
        'categories' => $_POST['categories'] ?? [],
        'tags' => $_POST['tags'] ?? [],
        'decoration_filter' => sanitize_text_field($_POST['filter'] ?? 'undecorated'),
    ];
    $limit = intval($_POST['limit'] ?? 10);
    $model = sanitize_text_field($_POST['model'] ?? '');

    $all_ids = Decofmt_Post_Meta::query_posts($args);
    $target_ids = array_slice($all_ids, 0, $limit);

    $allowed_models = array_keys(decofmt_get_models());
    if (!in_array($model, $allowed_models, true)) {
        $settings = get_option('decofmt_deco_settings', []);
        $model = $settings['model'] ?? 'claude-sonnet-4-6';
    }
    $cost_per_post = decofmt_get_cost_per_post($model);

    $estimated_cost = count($target_ids) * $cost_per_post;
    $estimated_time = count($target_ids) * 30;

    $preview_ids = array_slice($target_ids, 0, 20);
    $preview = [];
    foreach ($preview_ids as $id) {
        $preview[] = [
            'id' => $id,
            'title' => get_the_title($id),
            'edit_url' => get_edit_post_link($id, ''),
        ];
    }

    wp_send_json_success([
        'total' => count($all_ids),
        'target' => count($target_ids),
        'target_ids' => $target_ids,
        'preview' => $preview,
        'estimated_cost' => $estimated_cost,
        'estimated_time' => $estimated_time,
        'model' => $model,
        'cost_per_post' => $cost_per_post,
        'model_label' => decofmt_get_model_label($model),
    ]);
}

add_action('wp_ajax_decofmt_deco_bulk_process_one', 'decofmt_deco_ajax_bulk_process_one');
function decofmt_deco_ajax_bulk_process_one() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => '権限がありません']);
    }

    $post_id = intval($_POST['post_id'] ?? 0);
    $level = sanitize_text_field($_POST['level'] ?? 'standard');
    $model = sanitize_text_field($_POST['model'] ?? '');

    $allowed_models = array_keys(decofmt_get_models());
    if ($model && !in_array($model, $allowed_models, true)) {
        $model = '';
    }

    if (!$post_id) {
        wp_send_json_error(['message' => '記事IDが不正です']);
    }

    $options = ['level' => $level, 'dry_run' => false];
    if ($model) $options['model'] = $model;

    $result = Decofmt_Decorator::decorate_post($post_id, $options);

    if (is_wp_error($result)) {
        wp_send_json_success([
            'post_id' => $post_id,
            'title' => get_the_title($post_id),
            'result' => 'failure',
            'message' => $result->get_error_message(),
        ]);
    }

    wp_send_json_success([
        'post_id' => $post_id,
        'title' => get_the_title($post_id),
        'result' => 'success',
        'status' => $result['validation']['status'],
        'edit_url' => get_edit_post_link($post_id, ''),
    ]);
}

// =============================================================================
// 段落整形 AJAX
// =============================================================================

add_action('wp_ajax_decofmt_fmt_scan', 'decofmt_fmt_ajax_scan');
function decofmt_fmt_ajax_scan() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('権限がありません');
    @set_time_limit(120);

    $settings = decofmt_fmt_get_settings();
    $statuses = array_filter(array_map('trim', explode(',', $settings['target_statuses'] ?? 'publish,future,draft')));
    if (empty($statuses)) $statuses = ['publish', 'future', 'draft'];

    global $wpdb;
    $placeholders = implode(',', array_fill(0, count($statuses), '%s'));
    $query = $wpdb->prepare(
        "SELECT ID, post_title, post_content FROM {$wpdb->posts}
         WHERE post_type = 'post' AND post_status IN ($placeholders) ORDER BY ID DESC",
        ...$statuses
    );
    $rows = $wpdb->get_results($query);

    $targets = [];
    foreach ($rows as $r) {
        $stats = decofmt_fmt_stats($r->post_content, $settings);
        // 「長段落」「見出し昇格候補」「strong+コロン <li>」のいずれかで対象に
        // 「長段落」「見出し昇格候補」「strong+コロン <li>」「短めだが3句以上」のいずれかで対象に
        if ($stats['over_200'] <= 0
            && ($stats['heading_candidates'] ?? 0) <= 0
            && ($stats['strong_label_candidates'] ?? 0) <= 0
            && ($stats['multi_sentence_short'] ?? 0) <= 0) continue;
        $targets[] = [
            'id'                       => (int)$r->ID,
            'title'                    => $r->post_title,
            'count'                    => $stats['count'],
            'max'                      => $stats['max'],
            'over_200'                 => $stats['over_200'],
            'heading_candidates'       => $stats['heading_candidates'] ?? 0,
            'strong_label_candidates'  => $stats['strong_label_candidates'] ?? 0,
            'multi_sentence_short'     => $stats['multi_sentence_short'] ?? 0,
        ];
    }
    wp_send_json_success([
        'scanned' => count($rows),
        'posts'   => $targets,
    ]);
}

add_action('wp_ajax_decofmt_fmt_preview', 'decofmt_fmt_ajax_preview');
function decofmt_fmt_ajax_preview() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('権限がありません');

    $post_id = intval($_POST['post_id'] ?? 0);
    if (!$post_id) wp_send_json_error('post_id 不正');
    $post = get_post($post_id);
    if (!$post) wp_send_json_error('記事が見つかりません');

    $before = preg_replace('/<!--\s*\/?wp:[^>]*-->\s*/i', '', $post->post_content);
    $after_raw = decofmt_fmt_process_content($post->post_content);
    $after = preg_replace('/<!--\s*\/?wp:[^>]*-->\s*/i', '', $after_raw);

    wp_send_json_success([
        'before_html' => $before,
        'after_html'  => $after,
    ]);
}

add_action('wp_ajax_decofmt_fmt_apply', 'decofmt_fmt_ajax_apply');
function decofmt_fmt_ajax_apply() {
    check_ajax_referer('decofmt_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('権限がありません');
    @set_time_limit(60);

    $post_id = intval($_POST['post_id'] ?? 0);
    if (!$post_id) wp_send_json_error('post_id 不正');
    $post = get_post($post_id);
    if (!$post) wp_send_json_error('記事が見つかりません');

    // 変換前後の stats を取ることで、実際に何が変換されたか報告する。
    // 従来は「$new !== $original」だけを見ていたので、見出し前後の空段落追加だけで
    // 「成功」扱いになり、strong ラベルは分割されず残り続けても気付けなかった。
    $settings = decofmt_fmt_get_settings();
    $before_stats = decofmt_fmt_stats($post->post_content, $settings);
    $new = decofmt_fmt_process_content($post->post_content, $settings);
    $after_stats = decofmt_fmt_stats($new, $settings);

    $delta = [
        'over_200_resolved'         => max(0, $before_stats['over_200'] - $after_stats['over_200']),
        'heading_promoted'          => max(0, ($before_stats['heading_candidates'] ?? 0) - ($after_stats['heading_candidates'] ?? 0)),
        'strong_label_split'        => max(0, ($before_stats['strong_label_candidates'] ?? 0) - ($after_stats['strong_label_candidates'] ?? 0)),
        'multi_sentence_short_split'=> max(0, ($before_stats['multi_sentence_short'] ?? 0) - ($after_stats['multi_sentence_short'] ?? 0)),
    ];
    $delta_total = array_sum($delta);
    $remaining_after = [
        'over_200'                => $after_stats['over_200'],
        'heading_candidates'      => $after_stats['heading_candidates'] ?? 0,
        'strong_label_candidates' => $after_stats['strong_label_candidates'] ?? 0,
        'multi_sentence_short'    => $after_stats['multi_sentence_short'] ?? 0,
    ];
    $remaining_total = array_sum($remaining_after);

    if ($new === $post->post_content) {
        wp_send_json_success([
            'changed'         => false,
            'message'         => '変更なし',
            'delta'           => $delta,
            'remaining'       => $remaining_after,
            'remaining_total' => $remaining_total,
        ]);
    }

    set_transient('decofmt_fmt_skip_' . $post_id, 1, 30);
    $result = wp_update_post(['ID' => $post_id, 'post_content' => $new], true);
    delete_transient('decofmt_fmt_skip_' . $post_id);
    if (is_wp_error($result)) wp_send_json_error($result->get_error_message());

    wp_send_json_success([
        'changed'         => true,
        'delta'           => $delta,
        'delta_total'     => $delta_total,
        'remaining'       => $remaining_after,
        'remaining_total' => $remaining_total,
    ]);
}
