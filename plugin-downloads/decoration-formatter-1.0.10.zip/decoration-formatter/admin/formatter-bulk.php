<?php
/**
 * 段落整形 一括処理画面
 */

if (!defined('ABSPATH')) exit;

function decofmt_render_fmt_bulk_page() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div class="wrap decofmt-wrap">
        <h1>📝 段落整形 一括処理</h1>
        <p style="font-size:13px;line-height:1.7">
            既存の全記事をスキャンし、整形対象（200字超の段落を含む記事 or 見出し昇格候補あり）をリスト表示。
            プレビューで before/after を確認してから個別 or 一括で適用できます。<br>
            WP リビジョンが自動保存されるので<strong>適用後でも元に戻せます</strong>。
        </p>

        <div style="margin:16px 0">
            <button type="button" id="decofmt-fmt-scan-btn" class="button button-primary">🔍 全記事スキャン</button>
            <span id="decofmt-fmt-scan-status" style="margin-left:12px;color:#666;font-size:13px"></span>
        </div>

        <div id="decofmt-fmt-result" style="display:none">
            <div style="margin:0 0 12px">
                <button type="button" id="decofmt-fmt-apply-all-btn" class="button button-primary">✨ 全件に適用</button>
                <span id="decofmt-fmt-apply-status" style="margin-left:12px;font-size:13px"></span>
            </div>
            <table class="wp-list-table widefat striped">
                <thead>
                    <tr>
                        <th style="width:60px">ID</th>
                        <th>タイトル</th>
                        <th style="width:90px">段落数</th>
                        <th style="width:90px">最大字数</th>
                        <th style="width:120px">200字超</th>
                        <th style="width:140px">見出し昇格候補</th>
                        <th style="width:140px" title="&lt;li&gt;&lt;strong&gt;ラベル&lt;/strong&gt;：長文 パターン">strongラベル</th>
                        <th style="width:120px" title="200字以下だが句点3個以上の密段落">3句以上短段落</th>
                        <th style="width:220px">アクション</th>
                    </tr>
                </thead>
                <tbody id="decofmt-fmt-result-tbody"></tbody>
            </table>
        </div>
    </div>

    <script>
    (function ($) {
        // decofmt グローバルは wp_localize_script でフッターに出力されるため、
        // 本スクリプト（body内インライン）実行時点ではまだ未定義。
        // クリック時に評価するために関数化する。
        function cfg() {
            return {
                url:   (window.decofmt && decofmt.ajaxUrl) || (window.ajaxurl || ''),
                nonce: (window.decofmt && decofmt.nonce)   || ''
            };
        }
        let posts = [];

        $('#decofmt-fmt-scan-btn').on('click', scan);
        $('#decofmt-fmt-apply-all-btn').on('click', applyAll);

        async function scan() {
            const c = cfg();
            if (!c.nonce) { alert('プラグインJS未初期化：ページを再読み込みして再実行してください'); return; }
            $('#decofmt-fmt-scan-btn').prop('disabled', true);
            $('#decofmt-fmt-result').hide();
            $('#decofmt-fmt-result-tbody').empty();
            $('#decofmt-fmt-scan-status').text('スキャン中...');
            try {
                const res = await $.post(c.url, {
                    action: 'decofmt_fmt_scan',
                    nonce: c.nonce,
                });
                if (res === '-1' || res === -1) { alert('nonce認証エラー(-1)：ページを再読み込みして再実行してください'); return; }
                if (!res || !res.success) {
                    alert('スキャン失敗: ' + (res && res.data ? res.data : ''));
                    return;
                }
                posts = res.data.posts || [];
                $('#decofmt-fmt-scan-status').text(`スキャン完了: ${res.data.scanned}件チェック / 整形対象 ${posts.length}件`);
                render();
                if (posts.length) $('#decofmt-fmt-result').show();
            } catch (e) {
                const body = (e.responseText || '').trim();
                if (body === '-1') {
                    alert('nonce認証エラー(-1)：ページを再読み込みして再実行してください');
                } else {
                    alert('通信エラー: HTTP ' + (e.status || '?') + ' — ' + (body.substring(0, 300) || e.statusText || 'unknown'));
                }
            } finally {
                $('#decofmt-fmt-scan-btn').prop('disabled', false);
            }
        }

        function render() {
            const tbody = $('#decofmt-fmt-result-tbody').empty();
            posts.forEach(p => {
                const editUrl = `${location.origin}/wp-admin/post.php?post=${p.id}&action=edit`;
                const hc = p.heading_candidates || 0;
                const slc = p.strong_label_candidates || 0;
                const msc = p.multi_sentence_short || 0;
                tbody.append(`
                    <tr data-id="${p.id}">
                        <td>${p.id}</td>
                        <td><a href="${editUrl}" target="_blank">${esc(p.title)}</a></td>
                        <td>${p.count}</td>
                        <td>${p.max}字</td>
                        <td style="color:${p.over_200 > 0 ? '#dc2626' : '#6b7280'};font-weight:600">${p.over_200}件</td>
                        <td style="color:${hc > 0 ? '#d97706' : '#6b7280'};font-weight:600">${hc}件</td>
                        <td style="color:${slc > 0 ? '#2563eb' : '#6b7280'};font-weight:600">${slc}件</td>
                        <td style="color:${msc > 0 ? '#7c3aed' : '#6b7280'};font-weight:600">${msc}件</td>
                        <td>
                            <button type="button" class="button button-small decofmt-fmt-preview" data-id="${p.id}">👁 プレビュー</button>
                            <button type="button" class="button button-primary button-small decofmt-fmt-apply" data-id="${p.id}">✨ 適用</button>
                        </td>
                    </tr>
                `);
            });
            tbody.find('.decofmt-fmt-apply').on('click', function () {
                const id = $(this).data('id');
                applyOne(id, $(this));
            });
            tbody.find('.decofmt-fmt-preview').on('click', function () {
                const id = $(this).data('id');
                previewOne(id);
            });
        }

        async function previewOne(id) {
            const c = cfg();
            try {
                const res = await $.post(c.url, {
                    action: 'decofmt_fmt_preview',
                    nonce: c.nonce,
                    post_id: id,
                });
                if (res === '-1' || res === -1) { alert('nonce認証エラー(-1)：ページを再読み込みしてください'); return; }
                if (!res || !res.success) { alert('失敗'); return; }
                const w = window.open('', '_blank', 'width=1100,height=800');
                w.document.write(`
                    <html><head><title>プレビュー #${id}</title>
                    <style>body{font-family:sans-serif;font-size:14px;line-height:1.8;padding:20px;}
                    .grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
                    .col h2{margin-top:0;font-size:14px;background:#eee;padding:8px}
                    .col{border:1px solid #ddd;padding:12px;overflow:auto;max-height:90vh}
                    .col.after{background:#f0fdf4}
                    p{margin:0 0 14px;padding:6px;background:#fff;border-left:2px solid #d1d5db}
                    .col.after p{border-left-color:#16a34a}
                    </style></head><body>
                    <h1>段落整形プレビュー #${id}</h1>
                    <div class="grid">
                        <div class="col"><h2>Before</h2>${res.data.before_html}</div>
                        <div class="col after"><h2>After</h2>${res.data.after_html}</div>
                    </div>
                    </body></html>
                `);
                w.document.close();
            } catch (e) {
                alert('通信エラー: ' + (e.responseText || ''));
            }
        }

        // applyOne は {ok, changed, deltaTotal, remainingTotal} を返す
        async function applyOne(id, btn) {
            if (btn) btn.prop('disabled', true).text('適用中...');
            const c = cfg();
            try {
                const res = await $.post(c.url, {
                    action: 'decofmt_fmt_apply',
                    nonce: c.nonce,
                    post_id: id,
                });
                if (res === '-1' || res === -1) { alert('nonce認証エラー(-1)：ページを再読み込みしてください'); return { ok: false, changed: false, deltaTotal: 0, remainingTotal: 0 }; }
                if (res && res.success) {
                    const data = res.data || {};
                    const changed = !!data.changed;
                    const delta = data.delta || {};
                    const deltaTotal = (delta.over_200_resolved || 0) + (delta.heading_promoted || 0) + (delta.strong_label_split || 0) + (delta.multi_sentence_short_split || 0);
                    const remainingTotal = data.remaining_total || 0;
                    if (btn) {
                        let label;
                        if (deltaTotal > 0) {
                            label = `<span style="color:#16a34a;font-weight:600">✓ 変換 ${deltaTotal}カ所</span>`;
                        } else if (changed) {
                            // 内容は変わったが検出済みカウンタは動いていない（見出し前後の空段落など）
                            label = `<span style="color:#d97706;font-weight:600" title="整形はしたが検出済みパターンは分割できず">△ 整形のみ</span>`;
                        } else {
                            label = `<span style="color:#6b7280;font-weight:600">＝ 無変更</span>`;
                        }
                        if (remainingTotal > 0) {
                            label += ` <span style="color:#dc2626;font-size:11px">残 ${remainingTotal}件</span>`;
                        }
                        btn.replaceWith(label);
                    }
                    return { ok: true, changed, deltaTotal, remainingTotal };
                }
                alert('適用失敗: ' + (res && res.data ? res.data : ''));
            } catch (e) {
                alert('通信エラー: ' + (e.responseText || ''));
            } finally {
                if (btn && btn.prop) btn.prop('disabled', false);
            }
            return { ok: false, changed: false, deltaTotal: 0, remainingTotal: 0 };
        }

        async function applyAll() {
            if (!posts.length) { alert('対象がありません'); return; }
            if (!confirm(`${posts.length} 件に整形を適用します。リビジョンが自動保存されるので元に戻せます。よろしいですか？`)) return;
            $('#decofmt-fmt-apply-all-btn').prop('disabled', true);
            let done = 0, failed = 0, actuallyConverted = 0, noChange = 0, stillRemaining = 0;
            for (const p of posts) {
                $('#decofmt-fmt-apply-status').text(`適用中... ${done + failed}/${posts.length}件`);
                const btn = $(`tr[data-id="${p.id}"] .decofmt-fmt-apply`);
                const r = await applyOne(p.id, btn.length ? btn : null);
                if (r.ok) {
                    done++;
                    if (r.deltaTotal > 0) actuallyConverted++;
                    else noChange++;
                    if (r.remainingTotal > 0) stillRemaining++;
                } else {
                    failed++;
                }
            }
            $('#decofmt-fmt-apply-status').html(
                `完了: 成功 ${done}件 (実変換 ${actuallyConverted}件 / 変換なし ${noChange}件) / 失敗 ${failed}件` +
                (stillRemaining > 0 ? ` — <span style="color:#dc2626">検出済みパターンが残る記事 ${stillRemaining}件（下記スキャンで再確認）</span>` : '')
            );
            $('#decofmt-fmt-apply-all-btn').prop('disabled', false);
            // 適用後に自動で再スキャンして表を最新化する。
            // 従来は表がそのまま残り「27件成功したのにまだ27件ある」ように見えた。
            setTimeout(function () {
                $('#decofmt-fmt-scan-btn').trigger('click');
            }, 500);
        }

        function esc(s) {
            return String(s == null ? '' : s).replace(/[<>&"]/g, c =>
                ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c])
            );
        }
    })(jQuery);
    </script>
    <?php
}
