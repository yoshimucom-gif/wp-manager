<?php
/**
 * Plugin Name: 用語集
 * Description: 用語を「投稿」として1件ずつ登録し、一覧ページ（検索・カテゴリ・50音）を作ります。用語は指定したカテゴリに入れるだけで、目次・関連記事・監修者欄などテーマの機能がそのまま使えます。新着やRSSからは自動で外せます。会話の吹き出しは re:Diver の「会話」ブロックで描画し、話し手のアイコン・名前・色は設定画面から一括で変更できます。
 * Version: 1.1.3
 * Author: ミカタ株式会社
 * License: GPLv2 or later
 * Text Domain: uru-yougo
 */

if (!defined('ABSPATH')) exit;

define('UYG_VER', '1.1.3');
define('UYG_FILE', __FILE__);
define('UYG_DIR', plugin_dir_path(__FILE__));
define('UYG_URL', plugin_dir_url(__FILE__));

/**
 * 自動更新の置き場（update.json の URL）。空なら自動更新は無効。
 */
define('UYG_UPDATE_URL', 'https://raw.githubusercontent.com/yoshimucom-gif/wp-manager/main/plugin-host/api/plugin-update/uru-yougo');

if (UYG_UPDATE_URL) {
    require_once UYG_DIR . 'includes/plugin-updater.php';
    new UYG_Updater(__FILE__, UYG_UPDATE_URL);
}

require_once UYG_DIR . 'includes/class-uyg-settings.php';
require_once UYG_DIR . 'includes/class-uyg-render.php';

class Uru_Yougo {

    /**
     * 用語は通常の「投稿」として持つ。
     *
     * カスタム投稿タイプにすると re:Diver の目次・関連記事・SEOメタ（noindex）が
     * 効かないことを本番で実測した（2026-09-16）。テーマの機能を全部使えるほうを取る。
     */
    const PT = 'post';

    /** 50音の行。よみの先頭文字で振り分ける */
    public static function rows() {
        return array(
            'a'  => array('label' => 'あ行', 'chars' => 'あいうえおぁぃぅぇぉ'),
            'ka' => array('label' => 'か行', 'chars' => 'かきくけこがぎぐげご'),
            'sa' => array('label' => 'さ行', 'chars' => 'さしすせそざじずぜぞ'),
            'ta' => array('label' => 'た行', 'chars' => 'たちつてとだぢづでどっ'),
            'na' => array('label' => 'な行', 'chars' => 'なにぬねの'),
            'ha' => array('label' => 'は行', 'chars' => 'はひふへほばびぶべぼぱぴぷぺぽ'),
            'ma' => array('label' => 'ま行', 'chars' => 'まみむめも'),
            'ya' => array('label' => 'や行', 'chars' => 'やゆよゃゅょ'),
            'ra' => array('label' => 'ら行', 'chars' => 'らりるれろ'),
            'wa' => array('label' => 'わ行', 'chars' => 'わをんゎ'),
        );
    }

    /** よみ → 行キー。mbstring が無い環境でも動くようにしてある */
    public static function row_of($yomi) {
        $yomi = (string) $yomi;
        if (function_exists('mb_substr')) {
            $head = mb_substr($yomi, 0, 1, 'UTF-8');
        } else {
            $chars = preg_split('//u', $yomi, -1, PREG_SPLIT_NO_EMPTY);
            $head = isset($chars[0]) ? $chars[0] : '';
        }
        if ($head === '') return 'wa';
        foreach (self::rows() as $key => $row) {
            if (strpos($row['chars'], $head) !== false) return $key;
        }
        return 'wa';
    }

    /** 用語集カテゴリ。無ければ作る（$create=true のとき） */
    public static function cat($create = false) {
        $slug = UYG_Settings::get()['cat_slug'];
        $term = get_term_by('slug', $slug, 'category');
        if (!$term && $create) {
            $res = wp_insert_term('用語集', 'category', array('slug' => $slug));
            if (!is_wp_error($res)) $term = get_term($res['term_id'], 'category');
        }
        return $term ? $term : null;
    }

    public static function cat_id() {
        $t = self::cat();
        return $t ? (int) $t->term_id : 0;
    }

    /** この投稿は用語か */
    public static function is_term_post($post_id) {
        $id = self::cat_id();
        return $id && has_term($id, 'category', $post_id);
    }

    public function __construct() {
        add_action('init', array($this, 'register_meta'));
        add_action('wp_enqueue_scripts', array($this, 'assets'));
        add_action('add_meta_boxes', array($this, 'meta_box'));
        add_action('save_post_post', array($this, 'save_meta'), 10, 2);
        add_filter('the_content', array($this, 'single_content'));
        add_action('pre_get_posts', array($this, 'exclude_from_lists'));
        add_action('wp_head', array($this, 'maybe_noindex'), 1);
        register_activation_hook(UYG_FILE, array(__CLASS__, 'activate'));
    }

    public static function activate() {
        self::cat(true);   // 用語集カテゴリを用意する
    }

    /** 用語ごとの項目。REST経由でも書けるようにしておく */
    public function register_meta() {
        $fields = array(
            '_uyg_yomi'    => 'よみ（ひらがな）',
            '_uyg_summary' => '一行定義',
            '_uyg_talk'    => '会話（1行に「話し手: セリフ」）',
            '_uyg_links'   => '関連記事（1行に「URL|表示名」）',
            '_uyg_link_to' => '一覧のカードから別の記事へ送るURL',
            '_uyg_noindex' => '1 なら検索エンジンに載せない（本文を書くまでの間）',
        );
        foreach ($fields as $key => $desc) {
            register_post_meta(self::PT, $key, array(
                'type'          => 'string',
                'description'   => $desc,
                'single'        => true,
                'default'       => '',
                'show_in_rest'  => true,
                'auth_callback' => function () { return current_user_can('edit_posts'); },
            ));
        }
    }

    /**
     * 新着・RSS・日付/著者アーカイブから用語集カテゴリを外す。
     * 用語には用語集ページと検索から入ってもらう想定。
     */
    public function exclude_from_lists($q) {
        if (is_admin() || !$q->is_main_query()) return;
        if (empty(UYG_Settings::get()['exclude_from_lists'])) return;
        if (!($q->is_home() || $q->is_feed() || $q->is_date() || $q->is_author())) return;
        $id = self::cat_id();
        if (!$id) return;
        $ex = $q->get('category__not_in');
        $ex = is_array($ex) ? $ex : array();
        $ex[] = $id;
        $q->set('category__not_in', $ex);
    }

    /**
     * 本文をまだ書いていない用語を検索エンジンに載せない。
     *
     * re:Diver は diver_single_seo の noindex を robots メタとして出力しないため
     * （2026-09-16に本番で実測）、ここで自前で出す。
     */
    public function maybe_noindex() {
        if (!is_singular('post')) return;
        $id = get_the_ID();
        if (!$id || !self::is_term_post($id)) return;
        $flag = get_post_meta($id, '_uyg_noindex', true);
        $link_to = get_post_meta($id, '_uyg_link_to', true);
        if (empty($flag) && empty($link_to)) return;   // 指定が無ければ何もしない
        echo '<meta name="robots" content="noindex,follow">' . "
";
    }

    public function assets() {
        wp_register_style('uyg', UYG_URL . 'assets/yougo.css', array(), UYG_VER);
        wp_register_script('uyg', UYG_URL . 'assets/yougo.js', array(), UYG_VER, true);

        // 用語の投稿か、ショートコードを使っているページだけで読み込む。
        // 本文の描画中に enqueue すると読み込みが取りこぼされることがあるため、
        // ここ（wp_enqueue_scripts）で先に判定しておく。
        $need = false;
        if (is_singular()) {
            $post = get_post();
            if ($post) {
                $need = self::is_term_post($post->ID)
                     || has_shortcode($post->post_content, 'yougo')
                     || has_shortcode($post->post_content, 'yougo_talk');
            }
        }
        if ($need) {
            wp_enqueue_style('uyg');
            wp_enqueue_script('uyg');
            UYG_Render::enqueue_tokens();
        }
    }

    /* ── 編集画面（用語ごとの項目） ───────────────────────── */

    public function meta_box() {
        add_meta_box('uyg_fields', '用語集の設定', array($this, 'meta_box_html'), 'post', 'normal', 'default');
    }

    public function meta_box_html($post) {
        wp_nonce_field('uyg_save', 'uyg_nonce');
        $yomi    = get_post_meta($post->ID, '_uyg_yomi', true);
        $summary = get_post_meta($post->ID, '_uyg_summary', true);
        $talk    = get_post_meta($post->ID, '_uyg_talk', true);
        $links   = get_post_meta($post->ID, '_uyg_links', true);
        $link_to = get_post_meta($post->ID, '_uyg_link_to', true);
        $cat = self::cat();
        $names = array();
        foreach (UYG_Settings::speakers() as $s) $names[] = $s['label'];
        ?>
        <style>
        .uyg-f{margin:0 0 18px}
        .uyg-f label{display:block;font-weight:600;margin:0 0 5px}
        .uyg-f input[type=text],.uyg-f textarea{width:100%}
        .uyg-hint{background:#f0f6fc;border-left:4px solid #72aee6;padding:10px 12px;margin:0 0 16px}
        </style>
        <p class="uyg-hint">
            この投稿をカテゴリ「<strong><?php echo esc_html($cat ? $cat->name : '用語集'); ?></strong>」に
            入れると用語として扱われます。入れていない投稿では、ここの内容は使われません。
        </p>
        <div class="uyg-f">
            <label for="uyg_yomi">よみ（ひらがな）</label>
            <input type="text" id="uyg_yomi" name="uyg_yomi" value="<?php echo esc_attr($yomi); ?>" placeholder="ていとうけん">
            <p class="description">50音の並びと検索に使います。</p>
        </div>
        <div class="uyg-f">
            <label for="uyg_summary">一行定義</label>
            <textarea id="uyg_summary" name="uyg_summary" rows="3"><?php echo esc_textarea($summary); ?></textarea>
            <p class="description">一覧のカードと、記事冒頭の枠に出ます。80〜120字が目安です。</p>
        </div>
        <div class="uyg-f">
            <label for="uyg_talk">こんな場面で出てきます（会話）</label>
            <textarea id="uyg_talk" name="uyg_talk" rows="6" placeholder="担当者: 登記を取ってみたところ、まだ抵当権が付いたままですね。&#10;あなた: この状態でも売れるんでしょうか。"><?php echo esc_textarea($talk); ?></textarea>
            <p class="description">
                1行に1つ、「話し手: セリフ」の形で書きます。使える話し手は
                <strong><?php echo esc_html(implode('／', $names)); ?></strong>。
                アイコンと色は<a href="<?php echo esc_url(admin_url('options-general.php?page=uru-yougo')); ?>">設定 → 用語集</a>でまとめて変えられます。
            </p>
        </div>
        <div class="uyg-f">
            <label for="uyg_links">関連記事</label>
            <textarea id="uyg_links" name="uyg_links" rows="4" placeholder="/over-loan/|オーバーローンの家は売れる？"><?php echo esc_textarea($links); ?></textarea>
            <p class="description">1行に1つ、「URL|表示名」の形で書きます。</p>
        </div>
        <div class="uyg-f">
            <label><input type="checkbox" name="uyg_noindex" value="1"
                <?php checked(!empty(get_post_meta($post->ID, '_uyg_noindex', true))); ?>>
                この用語を検索エンジンに載せない</label>
            <p class="description">本文がまだ薄いあいだはチェックを入れておきます。
                書き上げたら外してください。</p>
        </div>
        <div class="uyg-f">
            <label for="uyg_link_to">一覧から別の記事へ送る（任意）</label>
            <input type="text" id="uyg_link_to" name="uyg_link_to" value="<?php echo esc_attr($link_to); ?>" placeholder="https://example.com/kiji/">
            <p class="description">
                すでにその用語を扱った記事がある場合に使います。入れると、一覧のカードはこのURLへリンクします。
            </p>
        </div>
        <?php
    }

    public function save_meta($post_id, $post) {
        if (!isset($_POST['uyg_nonce']) || !wp_verify_nonce($_POST['uyg_nonce'], 'uyg_save')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        update_post_meta($post_id, '_uyg_noindex', empty($_POST['uyg_noindex']) ? '' : '1');
        foreach (array('yomi', 'summary', 'talk', 'links', 'link_to') as $k) {
            if (!isset($_POST['uyg_' . $k])) continue;
            $val = wp_unslash($_POST['uyg_' . $k]);
            if ($k === 'yomi') $val = sanitize_text_field($val);
            elseif ($k === 'link_to') $val = esc_url_raw($val);
            else $val = sanitize_textarea_field($val);
            update_post_meta($post_id, '_uyg_' . $k, $val);
        }
    }

    /** 用語の投稿：本文の前後に定義枠・会話・関連を足す */
    public function single_content($content) {
        if (!is_singular('post') || !in_the_loop() || !is_main_query()) return $content;
        $id = get_the_ID();
        if (!self::is_term_post($id)) return $content;
        // 会話はまとめの前、関連記事と戻るリンクは記事の最後
        $content = UYG_Render::insert_before_matome($content, UYG_Render::term_talk($id));
        return UYG_Render::term_head($id) . $content . UYG_Render::term_foot($id);
    }
}

new Uru_Yougo();
