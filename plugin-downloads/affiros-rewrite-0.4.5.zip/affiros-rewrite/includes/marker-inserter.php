<?php
/**
 * 商品カードマーカー挿入エンジン
 *
 * 本体 app.py の insert_card_markers / DEFAULT_CARD_INSERTION_PATTERNS /
 * _build_marker / _find_matome_h2_range / _find_first_h2_range /
 * _find_last_h2_range / strip_leading_introduction_h2 /
 * strip_summary_table_sections を忠実に PHP 移植したもの。
 *
 * v0.4.4 変更点:
 *   - default_patterns() を本体 DEFAULT_CARD_INSERTION_PATTERNS と一致
 *     after_matome_h2 → after_last_h2 に統一（ranking/column）
 *     brand に after_last_h2 追加（2個体制）
 *   - after_last_h2 位置処理を insert() に追加（find_last_h2_range() 新設）
 *   - strip_summary_table_sections() を本体準拠に変更（早見表のみ削除、比較表は残す）
 *
 * 注: 本体は load_ad_insertion_patterns() でユーザー編集パターンを使えるが、
 *     プラグインは本体の JSON を読めないため DEFAULT 相当のみ対応。
 */

if (!defined('ABSPATH')) exit;

class Affiros_Rewrite_Marker_Inserter {

    /**
     * 記事タイプ別 既定の挿入パターン。
     * 本体 DEFAULT_CARD_INSERTION_PATTERNS と一致させること。
     */
    public static function default_patterns() {
        return [
            'ranking' => [
                ['position' => 'after_each_h3_rank', 'design' => 'vertical'],
                ['position' => 'after_last_h2',      'design' => 'ranking', 'count' => 3],
            ],
            'brand' => [
                // 商標記事は1商品深掘り構造。
                // after_first_h2: 冒頭近くでCV機会を最大化。
                // after_last_h2:  キーワード依存なし・記事末尾確定位置。
                //   intro H2 が strip されて after_first_h2 が失敗しても確実に入る。
                ['position' => 'after_first_h2', 'design' => 'vertical'],
                ['position' => 'after_last_h2',  'design' => 'vertical'],
            ],
            'column' => [
                ['position' => 'before_first_h2', 'design' => 'vertical', 'repeat' => 3],
                ['position' => 'after_last_h2',   'design' => 'ranking', 'count' => 3],
            ],
        ];
    }

    /**
     * 記事タイプに応じてマーカーを挿入する。本体 insert_card_markers の移植。
     */
    public static function insert($html, $article_type, $title = '') {
        if ($html === '' || $html === null) {
            return $html;
        }
        $patterns = self::default_patterns();
        $rules = $patterns[$article_type] ?? [];
        if (!$rules) {
            return $html;
        }

        $text = (string)$html;

        $text = self::strip_leading_introduction_h2($text, $title);
        $text = self::strip_summary_table_sections($text);

        $matome_range   = self::find_matome_h2_range($text);
        $first_h2_range = self::find_first_h2_range($text);
        $last_h2_range  = self::find_last_h2_range($text);

        $insertions = [];

        foreach ($rules as $rule) {
            $pos    = $rule['position'] ?? '';
            $design = $rule['design']   ?? 'vertical';
            $count  = $rule['count']    ?? null;
            $repeat = max(1, intval($rule['repeat'] ?? 1));
            $marker       = self::build_marker($design, $count);
            $marker_block = str_repeat("\n" . $marker, $repeat);

            if ($pos === 'top') {
                $insertions[] = [0, $marker_block . "\n"];
            } elseif ($pos === 'bottom') {
                $insertions[] = [strlen($text), "\n" . $marker_block];
            } elseif ($pos === 'before_first_h2' && $first_h2_range) {
                $insertions[] = [$first_h2_range[0], $marker_block . "\n"];
            } elseif ($pos === 'after_first_h2' && $first_h2_range) {
                $insertions[] = [$first_h2_range[1], "\n" . $marker_block];
            } elseif ($pos === 'before_matome_h2' && $matome_range) {
                $insertions[] = [$matome_range[0], $marker_block . "\n"];
            } elseif ($pos === 'after_matome_h2' && $matome_range) {
                $insertions[] = [$matome_range[1], "\n" . $marker_block];
            } elseif ($pos === 'after_last_h2' && $last_h2_range) {
                // キーワードに依存せず記事内の最後のH2直後に挿入。
                $insertions[] = [$last_h2_range[1], "\n" . $marker_block];
            } elseif ($pos === 'after_each_h3_rank') {
                foreach (self::collect_h3_rank_insertions($text, $marker, $matome_range, $first_h2_range) as $ins) {
                    $insertions[] = $ins;
                }
            }
        }

        usort($insertions, function ($a, $b) { return $b[0] - $a[0]; });
        foreach ($insertions as $ins) {
            $text = substr($text, 0, $ins[0]) . $ins[1] . substr($text, $ins[0]);
        }
        return $text;
    }

    /**
     * プラグイン用マーカー文字列を組み立てる。本体 _build_marker の移植。
     */
    private static function build_marker($design = 'vertical', $count = null) {
        if (!$design || $design === 'default') {
            return '<!--ai-product-->';
        }
        if ($design === 'ranking' && $count) {
            return '<!--ai-product:ranking:' . intval($count) . '-->';
        }
        return '<!--ai-product:' . $design . '-->';
    }

    /**
     * 「まとめ」を含むH2の [開始, 終了] バイト位置を返す。本体 _find_matome_h2_range の移植。
     */
    private static function find_matome_h2_range($html) {
        $re = '/<h2[^>]*>(?:(?!<\/h2>)[\s\S])*?(?:まとめ|総まとめ|結論|要点)(?:(?!<\/h2>)[\s\S])*?<\/h2>/iu';
        if (preg_match($re, $html, $m, PREG_OFFSET_CAPTURE)) {
            $start = $m[0][1];
            return [$start, $start + strlen($m[0][0])];
        }
        return null;
    }

    /**
     * 最初のH2の [開始, 終了] バイト位置を返す。本体 _find_first_h2_range の移植。
     */
    private static function find_first_h2_range($html) {
        $re = '/<h2[^>]*>(?:(?!<\/h2>)[\s\S])*?<\/h2>/iu';
        if (preg_match($re, $html, $m, PREG_OFFSET_CAPTURE)) {
            $start = $m[0][1];
            return [$start, $start + strlen($m[0][0])];
        }
        return null;
    }

    /**
     * 最後のH2の [開始, 終了] バイト位置を返す。本体 _find_last_h2_range の移植。
     */
    private static function find_last_h2_range($html) {
        $re = '/<h2[^>]*>(?:(?!<\/h2>)[\s\S])*?<\/h2>/iu';
        if (preg_match_all($re, $html, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
            $m = end($matches);
            $start = $m[0][1];
            return [$start, $start + strlen($m[0][0])];
        }
        return null;
    }

    /**
     * after_each_h3_rank: ランキング見出しのH3直後にマーカーを集める。
     */
    private static function collect_h3_rank_insertions($text, $marker, $matome_range, $first_h2_range) {
        $h3_patterns = [
            '/<h3[^>]*>\s*(?:第\s*)?(?:\d+|[０-９]+)\s*位[\s:：、・　]*[^<]*?<\/h3>/iu',
            '/<h3[^>]*>\s*No\.?\s*(?:\d+|[０-９]+)[\s:：、・　]*[^<]*?<\/h3>/iu',
            '/<h3[^>]*>\s*[①②③④⑤⑥⑦⑧⑨⑩][\s:：、・　]*[^<]*?<\/h3>/iu',
        ];
        $insertions = [];
        $seen = [];
        foreach ($h3_patterns as $re) {
            if (preg_match_all($re, $text, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $start = $m[0][1];
                    if (isset($seen[$start])) continue;
                    $seen[$start] = true;
                    $insertions[] = [$start + strlen($m[0][0]), "\n" . $marker];
                }
            }
        }
        if (!$seen) {
            $end_limit   = $matome_range   ? $matome_range[0]   : strlen($text);
            $start_limit = $first_h2_range ? $first_h2_range[1] : 0;
            if (preg_match_all('/<h3[^>]*>[^<]*?<\/h3>/iu', $text, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $start = $m[0][1];
                    if ($start < $start_limit || $start >= $end_limit) continue;
                    $insertions[] = [$start + strlen($m[0][0]), "\n" . $marker];
                }
            }
        }
        return $insertions;
    }

    /**
     * 記事冒頭の導入H2を物理削除する。本体 strip_leading_introduction_h2 の移植。
     */
    private static function strip_leading_introduction_h2($html, $title = '') {
        if ($html === '' || $html === null) return $html;
        $text = (string)$html;
        $re = '/\A\s*(?:<!--\s*wp:heading[^>]*-->\s*)?<h2([^>]*)>((?:(?!<\/h2>)[\s\S])*?)<\/h2>(?:\s*<!--\s*\/wp:heading\s*-->)?/iu';
        if (!preg_match($re, $text, $m, PREG_OFFSET_CAPTURE)) return $text;
        $match_end = $m[0][1] + strlen($m[0][0]);
        $h2_inner  = trim(preg_replace('/<[^>]+>/', '', $m[2][0]));
        $intro_keywords = [
            'とは', '結論', '選ぶポイント', '選定ポイント', '本記事の', '解説',
            'について', 'を知る', '記事のポイント',
            '完全ガイド', '完全攻略', '徹底ガイド', '徹底解説', '徹底比較',
            'おすすめ', '比較', 'ランキング', '選び方', '選定基準',
        ];
        $is_intro = false;
        foreach ($intro_keywords as $kw) {
            if (mb_strpos($h2_inner, $kw) !== false) { $is_intro = true; break; }
        }
        if (!$is_intro && $title !== '') {
            $norm = function ($s) {
                return mb_strtolower(preg_replace('/[\s\|｜・:：－—\-　]+/u', '', (string)$s), 'UTF-8');
            };
            $nt = $norm($title); $nh = $norm($h2_inner);
            if ($nt !== '' && $nh !== '') {
                if (mb_strpos($nt, $nh) !== false || mb_strpos($nh, $nt) !== false) {
                    $is_intro = true;
                } else {
                    $t_chars = self::unique_chars($nt);
                    $h_chars = self::unique_chars($nh);
                    $common = 0;
                    foreach ($t_chars as $c) { if (in_array($c, $h_chars, true)) $common++; }
                    if ($common / max(1, count($t_chars)) >= 0.7) $is_intro = true;
                }
            }
        }
        return $is_intro ? ltrim(substr($text, $match_end)) : $text;
    }

    /**
     * 早見表系のH2セクションを削除する。本体 strip_summary_table_sections の移植。
     *
     * 本体方針:「比較表はユーザーの正当なコンテンツなので削除しない。
     * 生成プロンプトで『作るな』と明示している『早見表』だけを掃除する。」
     * → キーワードを早見表系のみに限定。比較表・スペック表等は削除しない。
     */
    private static function strip_summary_table_sections($html) {
        if ($html === '' || $html === null) return $html;
        $text = (string)$html;
        $kw = '早見表|早分かり|早わかり|一目でわかる|一目で分かる';
        $pat = '/(?:<!--\s*wp:heading[^>]*-->\s*)?'
            . '<h2[^>]*>(?:(?!<\/h2>)[\s\S])*?(?:' . $kw . ')(?:(?!<\/h2>)[\s\S])*?<\/h2>'
            . '(?:\s*<!--\s*\/wp:heading\s*-->)?'
            . '[\s\S]*?'
            . '(?=<h2|<!--\s*wp:heading|<h3[^>]*>\s*(?:<!--\s*wp:[^>]*-->\s*)?(?:第\s*)?[\d０-９]+\s*位|$)/iu';
        for ($i = 0; $i < 2; $i++) {
            $replaced = preg_replace($pat, '', $text);
            if ($replaced === null) return (string)$html;
            $text = $replaced;
        }
        return $text;
    }

    private static function unique_chars($s) {
        $chars = preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY);
        return is_array($chars) ? array_values(array_unique($chars)) : [];
    }
}
