<?php
/**
 * 描画（ショートコードと個別ページ）
 *
 * 会話は re:Diver の「会話」ブロック（dbp/voice）の保存書式を組み立てて do_blocks() に通す。
 * そうするとテーマ側が吹き出しのCSSを自分で読み込むので、こちらでCSSを持たなくて済む。
 */

if (!defined('ABSPATH')) exit;

class UYG_Render {

    public static function init() {
        add_shortcode('yougo', array(__CLASS__, 'sc_yougo'));
        add_shortcode('yougo_talk', array(__CLASS__, 'sc_talk'));
    }

    /* ── 共通 ───────────────────────────────────────────── */

    /** 設定の配色をCSS変数として1回だけ出す */
    public static function enqueue_tokens() {
        static $done = false;
        if ($done) return;
        $done = true;
        $o = UYG_Settings::get();
        $css = sprintf(
            '.uyg{--uyg-accent:%s;--uyg-gold:%s;--uyg-link:%s}',
            esc_attr($o['accent']), esc_attr($o['gold']), esc_attr($o['link'])
        );
        wp_enqueue_style('uyg');
        wp_add_inline_style('uyg', $css);
    }

    /** アイコン未設定のときの仮アバター */
    private static function fallback_avatar($color) {
        $svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'>"
             . "<circle cx='50' cy='50' r='50' fill='" . $color . "'/>"
             . "<circle cx='50' cy='38' r='16' fill='#ffffff' opacity='.92'/>"
             . "<path d='M50 60c-16 0-28 10-30 24h60c-2-14-14-24-30-24z' fill='#ffffff' opacity='.92'/>"
             . "</svg>";
        return 'data:image/svg+xml;charset=utf-8,' . rawurlencode($svg);
    }

    /** 吹き出し1つ分。re:Diver の dbp/voice をそのまま組み立てる */
    public static function voice($label, $text) {
        $speakers = UYG_Settings::speakers();
        $o = UYG_Settings::get();
        $s = isset($speakers[$label])
            ? $speakers[$label]
            : array('label' => $label, 'image_id' => 0, 'bubble' => '#eef1f5', 'side' => 'left');

        $url = $s['image_id'] ? wp_get_attachment_image_url($s['image_id'], 'thumbnail') : '';
        if (!$url) {
            $url = self::fallback_avatar($s['side'] === 'right' ? $o['gold'] : $o['accent']);
        }
        $dir = $s['side'];

        $attrs = wp_json_encode(array(
            'direction'       => $dir,
            'name'            => $s['label'],
            'icomImageUrl'    => $url,
            'icomImageWidth'  => '150',
            'icomImageHeight' => '150',
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $html = '<div class="wp-block-dbp-voice is-voice-direction-' . esc_attr($dir)
              . ' is-voice-layout-inline is-fit-content dbp-voice"'
              . ' style="--dbp-voice--color:' . esc_attr($s['bubble']) . '">'
              . '<div class="dbp-voice-icon">'
              . '<img class="dbp-voice-icon-img" src="' . esc_url($url) . '" width="150" height="150" alt=""/>'
              . '<div class="dbp-voice-meta"><div class="dbp-voice-meta-name">'
              . esc_html($s['label']) . '</div></div></div>'
              . '<div class="dbp-voice-text has-content-gap">'
              . '<p class="wp-block-paragraph">' . esc_html($text) . '</p></div></div>';

        // do_blocks を通すことで、テーマが dbp/voice のCSSを自分で読み込む
        return do_blocks("<!-- wp:dbp/voice {$attrs} -->\n{$html}\n<!-- /wp:dbp/voice -->");
    }

    /** 「話し手: セリフ」の行たちを吹き出しに変える */
    public static function talk($raw) {
        $lines = preg_split('/\r\n|\r|\n/', (string) $raw);
        $out = '';
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            // 全角コロンにも対応する
            if (!preg_match('/^(.{1,12}?)\s*[:：]\s*(.+)$/u', $line, $m)) continue;
            $out .= self::voice(trim($m[1]), trim($m[2]));
        }
        if ($out === '') return '';
        return '<div class="uyg uyg-talk">' . $out . '</div>';
    }

    /* ── 個別ページ ─────────────────────────────────────── */

    public static function term_head($id) {
        self::enqueue_tokens();
        $yomi = get_post_meta($id, '_uyg_yomi', true);
        $sum  = get_post_meta($id, '_uyg_summary', true);
        if ($sum === '' && $yomi === '') return '';

        $cat = '';
        $sub = self::sub_term($id);
        if ($sub) $cat = $sub->name;

        $h  = '<div class="uyg uyg-term">';
        $h .= '<div class="uyg-term-head">';
        $h .= '<span class="uyg-term-name">' . esc_html(get_the_title($id)) . '</span>';
        if ($yomi) $h .= '<span class="uyg-term-yomi">' . esc_html($yomi) . '</span>';
        if ($cat)  $h .= '<span class="uyg-term-cat">' . esc_html($cat) . '</span>';
        $h .= '</div>';
        if ($sum) $h .= '<p class="uyg-term-def">' . esc_html($sum) . '</p>';
        $h .= '</div>';
        return $h;
    }

    /** 会話のかたまり。まとめの前に差し込むのでここだけ切り出してある */
    public static function term_talk($id) {
        $talk = get_post_meta($id, '_uyg_talk', true);
        if (trim((string) $talk) === '') return '';
        return '<h2 class="wp-block-heading">こんな場面で出てきます</h2>' . self::talk($talk);
    }

    /**
     * 会話を「まとめ」の直前に差し込む。
     * まとめのあとに置くと記事が締まったあとに話が続いてしまう（2026-09-17 差し戻し）。
     */
    public static function insert_before_matome($content, $block) {
        if ($block === '') return $content;
        if (preg_match('/<h2[^>]*>\s*(?:<[^>]+>\s*)*[^<]*まとめ[^<]*<\/h2>/u', $content, $m, PREG_OFFSET_CAPTURE)) {
            $at = $m[0][1];
            return substr($content, 0, $at) . $block . substr($content, $at);
        }
        return $content . $block;   // まとめが無ければ末尾
    }

    public static function term_foot($id) {
        $out = '';

        $links = self::parse_links(get_post_meta($id, '_uyg_links', true));
        if ($links) {
            $out .= '<div class="uyg uyg-links"><p class="uyg-links-title">もっと詳しく</p><ul>';
            foreach ($links as $l) {
                $out .= '<li><a href="' . esc_url($l['url']) . '">' . esc_html($l['label']) . '</a></li>';
            }
            $out .= '</ul></div>';
        }

        $hub = UYG_Settings::get()['hub_url'];
        if ($hub) {
            $url = preg_match('#^https?://#', $hub) ? $hub : home_url($hub);
            $out .= '<div class="uyg uyg-back"><a href="' . esc_url($url) . '">'
                  . '用語集の一覧へ戻る</a></div>';
        }
        return $out;
    }

    /** その投稿が属する「用語集の子カテゴリ」を1つ返す */
    public static function sub_term($post_id) {
        $parent = Uru_Yougo::cat_id();
        if (!$parent) return null;
        $terms = wp_get_post_terms($post_id, 'category');
        if (is_wp_error($terms)) return null;
        foreach ($terms as $t) {
            if ((int) $t->parent === $parent) return $t;
        }
        return null;
    }

    private static function parse_links($raw) {
        $out = array();
        foreach (preg_split('/\r\n|\r|\n/', (string) $raw) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = explode('|', $line, 2);
            $url = trim($parts[0]);
            if ($url === '') continue;
            $out[] = array('url' => $url, 'label' => isset($parts[1]) ? trim($parts[1]) : $url);
        }
        return $out;
    }

    /* ── ショートコード ─────────────────────────────────── */

    /** [yougo_talk]担当者: …[/yougo_talk] */
    public static function sc_talk($atts, $content = '') {
        self::enqueue_tokens();
        return self::talk(wp_strip_all_tags($content));
    }

    /**
     * [yougo]                 … 用語集の一覧
     * [yougo cat="zei"]       … そのカテゴリだけ
     * [yougo term="媒介契約"] … その用語のカードを1枚
     */
    public static function sc_yougo($atts) {
        $a = shortcode_atts(array('cat' => '', 'term' => '', 'search' => '1'), $atts, 'yougo');
        self::enqueue_tokens();

        if ($a['term'] !== '') return self::one_card($a['term']);

        $cat_id = Uru_Yougo::cat_id();
        if (!$cat_id) return '<p>用語集カテゴリがまだありません。設定 → 用語集で確認してください。</p>';

        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'cat'            => $cat_id,
            'orderby'        => 'meta_value',
            'meta_key'       => '_uyg_yomi',
            'order'          => 'ASC',
            'ignore_sticky_posts' => true,
        );
        if ($a['cat'] !== '') {
            $args['category_name'] = implode(',', array_map('trim', explode(',', $a['cat'])));
        }
        $q = new WP_Query($args);
        if (!$q->have_posts()) return '<p>用語がまだ登録されていません。</p>';

        wp_enqueue_script('uyg');

        $by_row = array();
        foreach ($q->posts as $p) {
            $yomi = get_post_meta($p->ID, '_uyg_yomi', true);
            $by_row[Uru_Yougo::row_of($yomi)][] = $p;
        }

        $cats = get_terms(array('taxonomy' => 'category', 'hide_empty' => true,
                                'child_of' => $cat_id));
        $total = count($q->posts);

        ob_start(); ?>
        <div class="uyg uyg-list" id="uyg-list">
            <?php if ($a['search'] !== '0') : ?>
            <div class="uyg-bar">
                <div class="uyg-search">
                    <input type="search" id="uyg-q" autocomplete="off"
                           placeholder="用語・よみ・説明から検索" aria-label="用語集を検索">
                    <button type="button" class="uyg-clear" aria-label="検索をクリア">×</button>
                </div>
                <div class="uyg-chips" role="group" aria-label="カテゴリで絞り込み">
                    <button type="button" class="uyg-chip" data-cat="all" aria-pressed="true">すべて</button>
                    <?php foreach ($cats as $c) : ?>
                    <button type="button" class="uyg-chip" data-cat="<?php echo esc_attr($c->slug); ?>"
                            aria-pressed="false"><?php echo esc_html($c->name); ?></button>
                    <?php endforeach; ?>
                </div>
                <div class="uyg-idx" role="group" aria-label="50音で移動">
                    <?php foreach (Uru_Yougo::rows() as $key => $row) : ?>
                    <button type="button" class="uyg-go" data-go="<?php echo esc_attr($key); ?>"
                        <?php disabled(empty($by_row[$key])); ?>><?php echo esc_html($row['label']); ?></button>
                    <?php endforeach; ?>
                </div>
                <p class="uyg-count" id="uyg-count" aria-live="polite" data-total="<?php echo (int) $total; ?>">
                    <b><?php echo (int) $total; ?></b> 語を表示中</p>
            </div>
            <?php endif; ?>

            <?php foreach (Uru_Yougo::rows() as $key => $row) :
                if (empty($by_row[$key])) continue; ?>
            <section class="uyg-row" data-row="<?php echo esc_attr($key); ?>">
                <h2 class="uyg-row-h"><i aria-hidden="true"></i><?php echo esc_html($row['label']); ?>
                    <span><?php echo count($by_row[$key]); ?>語</span></h2>
                <div class="uyg-grid">
                    <?php foreach ($by_row[$key] as $p) echo self::card($p, $key); ?>
                </div>
            </section>
            <?php endforeach; ?>

            <div class="uyg-empty">
                <p>該当する用語が見つかりませんでした。</p>
                <small>ひらがな・カタカナ・漢字のどれでも検索できます。</small>
            </div>
        </div>
        <?php
        wp_reset_postdata();
        return ob_get_clean();
    }

    private static function one_card($title) {
        $q = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 1,
                                'cat' => Uru_Yougo::cat_id(), 'title' => $title,
                                'ignore_sticky_posts' => true));
        $p = $q->have_posts() ? $q->posts[0] : null;
        if (!$p) return '';
        return '<div class="uyg uyg-list uyg-solo">' . self::card($p, '') . '</div>';
    }

    private static function card($p, $row) {
        $yomi = get_post_meta($p->ID, '_uyg_yomi', true);
        $sum  = get_post_meta($p->ID, '_uyg_summary', true);
        $sub = self::sub_term($p->ID);
        $cat_slug = $sub ? $sub->slug : '';
        $cat_name = $sub ? $sub->name : '';
        $hay = $p->post_title . ' ' . $yomi . ' ' . $sum . ' ' . $cat_name;
        // すでにその用語の記事がある場合は、そちらへ送る
        $link_to = get_post_meta($p->ID, '_uyg_link_to', true);
        $url = $link_to ? $link_to : get_permalink($p);

        $h  = '<article class="uyg-card" data-cat="' . esc_attr($cat_slug) . '"'
            . ' data-row="' . esc_attr($row) . '" data-k="' . esc_attr($hay) . '">';
        $h .= '<div class="uyg-card-head">';
        $h .= '<h3 class="uyg-term"><a href="' . esc_url($url) . '">'
            . esc_html($p->post_title) . '</a></h3>';
        if ($yomi) $h .= '<span class="uyg-yomi">' . esc_html($yomi) . '</span>';
        if ($cat_name) $h .= '<span class="uyg-badge">' . esc_html($cat_name) . '</span>';
        $h .= '</div>';
        if ($sum) $h .= '<p class="uyg-def">' . esc_html($sum) . '</p>';
        $h .= '<p class="uyg-more"><a href="' . esc_url($url) . '">くわしく見る</a></p>';
        $h .= '</article>';
        return $h;
    }
}

UYG_Render::init();
