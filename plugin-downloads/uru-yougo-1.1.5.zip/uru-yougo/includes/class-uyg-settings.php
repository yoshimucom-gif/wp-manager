<?php
/**
 * 設定画面（設定 → 用語集）
 *
 * 会話の話し手（名前・アイコン・吹き出しの色・左右）をここでまとめて持つ。
 * 用語を何語登録していても、ここを1回直せば全部の会話に反映される。
 */

if (!defined('ABSPATH')) exit;

class UYG_Settings {

    const OPT = 'uyg_options';

    public static function defaults() {
        return array(
            'cat_slug'           => 'yougo',   // 用語を入れるカテゴリのスラッグ
            'exclude_from_lists' => 1,         // 新着・RSSから外す
            'hub_url'            => '/yougoshu/',
            'accent'   => '#1f2e43',   // 見出し・罫のネイビー
            'gold'     => '#bb9c5e',   // 差し色
            'link'     => '#0652c9',
            'speakers' => array(
                array('label' => '担当者',   'image_id' => 0, 'bubble' => '#eef1f5', 'side' => 'left'),
                array('label' => 'あなた',   'image_id' => 0, 'bubble' => '#fbf3e4', 'side' => 'right'),
                array('label' => '税理士',   'image_id' => 0, 'bubble' => '#eef4f2', 'side' => 'left'),
                array('label' => '司法書士', 'image_id' => 0, 'bubble' => '#eef2f8', 'side' => 'left'),
                array('label' => '弁護士',   'image_id' => 0, 'bubble' => '#f7eef3', 'side' => 'left'),
                array('label' => '銀行',     'image_id' => 0, 'bubble' => '#eff2f5', 'side' => 'left'),
                array('label' => '買主',     'image_id' => 0, 'bubble' => '#f8f0ec', 'side' => 'left'),
            ),
        );
    }

    public static function get() {
        $saved = get_option(self::OPT, array());
        if (!is_array($saved)) $saved = array();
        $out = wp_parse_args($saved, self::defaults());
        if (empty($out['speakers']) || !is_array($out['speakers'])) {
            $out['speakers'] = self::defaults()['speakers'];
        }
        return $out;
    }

    /** 話し手をラベル引きできる形で返す */
    public static function speakers() {
        $out = array();
        foreach (self::get()['speakers'] as $s) {
            $label = isset($s['label']) ? trim($s['label']) : '';
            if ($label === '') continue;
            $out[$label] = array(
                'label'    => $label,
                'image_id' => isset($s['image_id']) ? (int) $s['image_id'] : 0,
                'bubble'   => isset($s['bubble']) ? $s['bubble'] : '#eef1f5',
                'side'     => (isset($s['side']) && $s['side'] === 'right') ? 'right' : 'left',
            );
        }
        return $out;
    }

    public function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'register'));
        add_action('admin_enqueue_scripts', array($this, 'assets'));
    }

    public function menu() {
        add_options_page('用語集', '用語集', 'manage_options', 'uru-yougo', array($this, 'page'));
    }

    public function register() {
        register_setting('uyg_group', self::OPT, array(
            'type'              => 'array',
            'sanitize_callback' => array($this, 'sanitize'),
            'default'           => self::defaults(),
        ));
    }

    public function sanitize($input) {
        $d = self::defaults();
        $out = array();
        foreach (array('accent', 'gold', 'link') as $k) {
            $v = isset($input[$k]) ? sanitize_hex_color($input[$k]) : '';
            $out[$k] = $v ? $v : $d[$k];
        }
        $out['cat_slug'] = isset($input['cat_slug'])
            ? sanitize_title($input['cat_slug']) : $d['cat_slug'];
        if ($out['cat_slug'] === '') $out['cat_slug'] = $d['cat_slug'];
        $out['exclude_from_lists'] = empty($input['exclude_from_lists']) ? 0 : 1;
        $out['hub_url'] = isset($input['hub_url'])
            ? esc_url_raw($input['hub_url']) : $d['hub_url'];

        $out['speakers'] = array();
        if (!empty($input['speakers']) && is_array($input['speakers'])) {
            foreach ($input['speakers'] as $s) {
                $label = isset($s['label']) ? sanitize_text_field($s['label']) : '';
                if (trim($label) === '') continue;   // 名前が空の行は捨てる
                $bubble = isset($s['bubble']) ? sanitize_hex_color($s['bubble']) : '';
                $out['speakers'][] = array(
                    'label'    => $label,
                    'image_id' => isset($s['image_id']) ? absint($s['image_id']) : 0,
                    'bubble'   => $bubble ? $bubble : '#eef1f5',
                    'side'     => (isset($s['side']) && $s['side'] === 'right') ? 'right' : 'left',
                );
            }
        }
        if (empty($out['speakers'])) $out['speakers'] = $d['speakers'];
        return $out;
    }

    public function assets($hook) {
        if ($hook !== 'settings_page_uru-yougo') return;
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }

    public function page() {
        $o = self::get();
        ?>
        <div class="wrap">
            <h1>用語集</h1>
            <p>会話の吹き出しに出る話し手を、ここでまとめて設定します。用語を何語登録していても、
               ここを直せば<strong>すべての会話に一度で反映</strong>されます。</p>

            <form method="post" action="options.php">
                <?php settings_fields('uyg_group'); ?>

                <h2>用語の置き場</h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">用語集カテゴリのスラッグ</th>
                        <td>
                            <input type="text" name="<?php echo self::OPT; ?>[cat_slug]"
                                   value="<?php echo esc_attr($o['cat_slug']); ?>" class="regular-text">
                            <p class="description">このカテゴリに入れた投稿が用語として扱われます。
                                8分類は、このカテゴリの<strong>子カテゴリ</strong>として作ってください。</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">新着・RSSから外す</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo self::OPT; ?>[exclude_from_lists]"
                                value="1" <?php checked(!empty($o['exclude_from_lists'])); ?>>
                                用語集カテゴリの投稿を、新着一覧・RSS・日付/著者アーカイブに出さない</label>
                            <p class="description">用語が増えても、記事の新着が用語で埋まりません。</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">用語集ページのURL</th>
                        <td><input type="text" name="<?php echo self::OPT; ?>[hub_url]"
                                   value="<?php echo esc_attr($o['hub_url']); ?>" class="regular-text">
                            <p class="description">用語の記事末に出す「一覧へ戻る」のリンク先です。</p></td>
                    </tr>
                </table>

                <h2>配色</h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">見出し・罫の色</th>
                        <td><input type="text" class="uyg-color" name="<?php echo self::OPT; ?>[accent]"
                                   value="<?php echo esc_attr($o['accent']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">差し色</th>
                        <td><input type="text" class="uyg-color" name="<?php echo self::OPT; ?>[gold]"
                                   value="<?php echo esc_attr($o['gold']); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row">リンクの色</th>
                        <td><input type="text" class="uyg-color" name="<?php echo self::OPT; ?>[link]"
                                   value="<?php echo esc_attr($o['link']); ?>"></td>
                    </tr>
                </table>

                <h2>会話の話し手</h2>
                <p class="description">用語の編集画面では、ここの「表示名」を使って
                   「<code>担当者: セリフ</code>」のように書きます。</p>
                <table class="widefat striped" id="uyg-speakers">
                    <thead>
                        <tr>
                            <th style="width:120px">アイコン</th>
                            <th style="width:180px">表示名</th>
                            <th style="width:150px">吹き出しの色</th>
                            <th style="width:120px">左右</th>
                            <th style="width:80px"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($o['speakers'] as $i => $s) : $this->row($i, $s); endforeach; ?>
                    </tbody>
                </table>
                <p><button type="button" class="button" id="uyg-add">話し手を追加</button></p>

                <?php submit_button(); ?>
            </form>
        </div>

        <script id="uyg-row-tmpl" type="text/template"><?php
            ob_start(); $this->row('__i__', array('label' => '', 'image_id' => 0, 'bubble' => '#eef1f5', 'side' => 'left'));
            echo str_replace(array('<', '>'), array('&lt;', '&gt;'), ob_get_clean());
        ?></script>
        <script>
        jQuery(function($){
            $('.uyg-color').wpColorPicker();
            var next = <?php echo count($o['speakers']); ?>;

            $('#uyg-add').on('click', function(){
                var tmpl = $('#uyg-row-tmpl').text().replace(/__i__/g, next++);
                $('#uyg-speakers tbody').append($('<div>').html(tmpl).text ? tmpl : tmpl);
                $('#uyg-speakers tbody tr:last .uyg-color').wpColorPicker();
            });

            $('#uyg-speakers').on('click', '.uyg-pick', function(e){
                e.preventDefault();
                var $cell = $(this).closest('td');
                var frame = wp.media({title:'アイコンを選ぶ', multiple:false,
                                      library:{type:'image'}, button:{text:'この画像にする'}});
                frame.on('select', function(){
                    var a = frame.state().get('selection').first().toJSON();
                    var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
                    $cell.find('input.uyg-img').val(a.id);
                    $cell.find('img.uyg-thumb').attr('src', url).show();
                });
                frame.open();
            });

            $('#uyg-speakers').on('click', '.uyg-del', function(){
                $(this).closest('tr').remove();
            });
        });
        </script>
        <style>
        #uyg-speakers img.uyg-thumb{width:52px;height:52px;border-radius:50%;object-fit:cover;
            border:1px solid #dcdcde;display:block;margin:0 0 6px}
        #uyg-speakers td{vertical-align:middle}
        </style>
        <?php
    }

    private function row($i, $s) {
        $name = self::OPT . '[speakers][' . $i . ']';
        $img  = !empty($s['image_id']) ? wp_get_attachment_image_url((int) $s['image_id'], 'thumbnail') : '';
        ?>
        <tr>
            <td>
                <img class="uyg-thumb" src="<?php echo esc_url($img); ?>" alt=""
                     style="<?php echo $img ? '' : 'display:none'; ?>">
                <input type="hidden" class="uyg-img" name="<?php echo esc_attr($name); ?>[image_id]"
                       value="<?php echo esc_attr((int) $s['image_id']); ?>">
                <button type="button" class="button uyg-pick">選ぶ</button>
            </td>
            <td><input type="text" name="<?php echo esc_attr($name); ?>[label]"
                       value="<?php echo esc_attr($s['label']); ?>" placeholder="担当者"></td>
            <td><input type="text" class="uyg-color" name="<?php echo esc_attr($name); ?>[bubble]"
                       value="<?php echo esc_attr($s['bubble']); ?>"></td>
            <td>
                <select name="<?php echo esc_attr($name); ?>[side]">
                    <option value="left" <?php selected($s['side'], 'left'); ?>>左</option>
                    <option value="right" <?php selected($s['side'], 'right'); ?>>右</option>
                </select>
            </td>
            <td><button type="button" class="button-link uyg-del">削除</button></td>
        </tr>
        <?php
    }
}

new UYG_Settings();
