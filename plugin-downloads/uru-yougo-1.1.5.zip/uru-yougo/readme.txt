=== 用語集 ===
Contributors: mikata
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

用語を1件ずつ登録して、一覧ページと用語ごとの個別ページを作ります。

== Description ==
「用語」という投稿タイプが増えます。1件ずつ登録すると、用語ごとのページが
/yougo/スラッグ/ にできて、検索エンジンにも1ページずつ載ります。

一覧はショートコード [yougo] を固定ページに貼るだけです。検索・カテゴリの絞り込み・
50音での移動が付きます。

会話の吹き出しは re:Diver の「会話」ブロックで描画します。話し手のアイコン・名前・
吹き出しの色は「設定 → 用語集」でまとめて変更でき、登録済みの全用語に一度で反映されます。

== ショートコード ==
[yougo]                  用語集の一覧
[yougo cat="zeikin"]     そのカテゴリの用語だけ
[yougo term="媒介契約"]  その用語のカードを1枚
[yougo_talk]…[/yougo_talk]  記事の中で会話の吹き出しを使う
