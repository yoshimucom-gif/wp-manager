/* 用語集の一覧：検索・カテゴリ絞り込み・50音移動 */
(function () {
  var root = document.getElementById('uyg-list');
  if (!root) return;

  var input = root.querySelector('#uyg-q');
  var wrap = root.querySelector('.uyg-search');
  var clear = root.querySelector('.uyg-clear');
  var count = root.querySelector('#uyg-count');
  var bar = root.querySelector('.uyg-bar');
  var cards = [].slice.call(root.querySelectorAll('.uyg-card'));
  var rows = [].slice.call(root.querySelectorAll('.uyg-row'));
  var chips = [].slice.call(root.querySelectorAll('.uyg-chip'));
  var goes = [].slice.call(root.querySelectorAll('.uyg-go'));
  var total = count ? parseInt(count.getAttribute('data-total'), 10) || cards.length : cards.length;
  var cat = 'all';
  var timer = null;

  // カタカナはひらがなに寄せる。記号と空白は落として比較する
  function kana(s) {
    return s.replace(/[ァ-ヶ]/g, function (c) {
      return String.fromCharCode(c.charCodeAt(0) - 0x60);
    });
  }
  function norm(s) {
    return kana(String(s).toLowerCase())
      .replace(/[\s　ー・()（）\-]/g, '');
  }

  cards.forEach(function (c) {
    c.setAttribute('data-hay', norm(c.getAttribute('data-k') || ''));
  });

  function apply() {
    var q = input ? norm(input.value) : '';
    var shown = 0;
    var per = {};
    cards.forEach(function (c) {
      var ok = (cat === 'all' || c.getAttribute('data-cat') === cat) &&
               (!q || c.getAttribute('data-hay').indexOf(q) >= 0);
      c.hidden = !ok;
      if (ok) {
        var r = c.getAttribute('data-row');
        shown++;
        per[r] = (per[r] || 0) + 1;
      }
    });
    rows.forEach(function (r) {
      var n = per[r.getAttribute('data-row')] || 0;
      r.hidden = !n;
      var s = r.querySelector('.uyg-row-h span');
      if (s) s.textContent = n + '語';
    });
    goes.forEach(function (b) { b.disabled = !per[b.getAttribute('data-go')]; });
    if (count) {
      count.innerHTML = '<b>' + shown + '</b> 語を表示中' +
        '<span style="opacity:.55"> ／ 全' + total + '語</span>';
    }
    root.className = shown === 0 ? 'uyg uyg-list is-empty' : 'uyg uyg-list';
    if (wrap) wrap.className = (input && input.value) ? 'uyg-search is-filled' : 'uyg-search';
  }

  if (input) {
    input.addEventListener('input', function () {
      clearTimeout(timer);
      timer = setTimeout(apply, 110);
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { input.value = ''; apply(); }
    });
  }
  if (clear) {
    clear.addEventListener('click', function () { input.value = ''; apply(); input.focus(); });
  }

  chips.forEach(function (ch) {
    ch.addEventListener('click', function () {
      cat = ch.getAttribute('data-cat');
      chips.forEach(function (o) { o.setAttribute('aria-pressed', o === ch ? 'true' : 'false'); });
      apply();
    });
  });

  goes.forEach(function (b) {
    b.addEventListener('click', function () {
      var el = root.querySelector('.uyg-row[data-row="' + b.getAttribute('data-go') + '"]');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  // 固定ヘッダーの高さは実測する（テーマやスクロール位置で変わるため決め打ちにしない）
  function offset() {
    var h = 0;
    [].slice.call(document.querySelectorAll('header,#header,[class*="header"]')).forEach(function (el) {
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
      var r = el.getBoundingClientRect();
      if (r.top <= 2 && r.bottom > 0 && r.bottom < 220 && r.width > window.innerWidth * 0.6) {
        h = Math.max(h, r.bottom);
      }
    });
    root.style.setProperty('--uyg-top', h + 'px');
  }

  // テーマ側が #content に overflow:hidden を掛けていると position:sticky が効かない
  (function () {
    var p = root.parentElement;
    while (p && p !== document.body && p !== document.documentElement) {
      var cs = getComputedStyle(p);
      if (cs.overflowX !== 'visible' || cs.overflowY !== 'visible') p.style.overflow = 'visible';
      p = p.parentElement;
    }
  })();

  var raf = null;
  function onScroll() {
    if (raf) return;
    raf = requestAnimationFrame(function () { raf = null; offset(); });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });

  offset();
  apply();
})();
