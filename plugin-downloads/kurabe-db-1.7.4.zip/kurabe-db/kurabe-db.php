<?php
/**
 * Plugin Name: 100均くらべ 比較データ表示
 * Description: 品目ごとの比較データ（ダイソー・キャンドゥ・ワッツの公式通販から取得した仕様）を投稿メタ kurabe_data に保存し、ショートコード [kurabe part="..."] で出典・数字・一覧表・縮尺図・通販リンクを表示します。見出しと本文の見た目はテーマに任せ、このプラグインは部品だけを描きます。
 * Version:     1.7.4
 * Author:      Keys
 * License:     GPLv2 or later
 * Text Domain: kurabe-db
 */

if (!defined('ABSPATH')) {
    exit;
}

/* 自動更新（GitHub直配信）。機能より先に入れる決まり */
require_once __DIR__ . '/includes/plugin-updater.php';
add_action('init', function () {
    new Kurabe_Db_Plugin_Updater(
        __FILE__,
        'https://raw.githubusercontent.com/yoshimucom-gif/wp-manager/main/plugin-host/api/plugin-update/kurabe-db'
    );
});

class Kurabe_Db
{
    const VERSION  = '1.7.4';
    const META     = 'kurabe_data';
    const OPT      = 'kurabe_db_settings';
    const STORES   = array('ダイソー' => 'daiso', 'キャンドゥ' => 'cando', 'ワッツ' => 'watts');
    /* 店名バッジと絞り込みに出す表記（各社のロゴ表記） */
    const LABELS   = array('ダイソー' => 'DAISO', 'キャンドゥ' => 'Can★Do', 'ワッツ' => 'Watts');

    private static $used = false;

    public static function boot()
    {
        add_action('init', array(__CLASS__, 'register_meta'));
        add_shortcode('kurabe', array(__CLASS__, 'shortcode'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_init', array(__CLASS__, 'admin_init'));
        add_filter('diver_single_side_items', array(__CLASS__, 'side_items'));
        add_filter('get_post_metadata', array(__CLASS__, 'layout_title_normal'), 10, 4);
        add_action('diver_single_main_section', array(__CLASS__, 'full_width_header'), 5);
        add_action('diver_main_before', array(__CLASS__, 'archive_table'), 20);
        add_shortcode('kurabe_list', array(__CLASS__, 'list_shortcode'));
        add_shortcode('kurabe_top', array(__CLASS__, 'top_shortcode'));
        add_action('rest_api_init', array(__CLASS__, 'rest_selfupdate'));
        add_filter('wp_robots', array(__CLASS__, 'robots_while_private'), 999);
        add_action('wp_head', array(__CLASS__, 'tag_meta_description'), 2);
        add_action('wp_head', array(__CLASS__, 'category_colors'), 99);
    }

    /* カテゴリの色を3社の色（差し色）で順に割り振る。カードのカテゴリラベル（.p-cat-ID）と、TOPのジャンルのアイコンで同じ色
       （吉村さん 2026-10-01「カテゴリーのラベル、差し色で何か設定して」）。re:Diver にカテゴリ色の設定項目が無いので出力で当てる */
    const CAT_COLORS = array(array('#f5008c', '#FDE6F2'), array('#e94709', '#FDECE5'), array('#6a5246', '#F0ECEA'));

    public static function category_color_index($term_id)
    {
        static $map = null;
        if ($map === null) {
            $map = array();
            $ids = get_terms(array('taxonomy' => 'category', 'hide_empty' => false, 'fields' => 'ids', 'orderby' => 'id'));
            $ids = is_array($ids) ? array_map('intval', array_values($ids)) : array();
            sort($ids);
            $i = 0;
            foreach ($ids as $id) {
                $map[$id] = $i++ % 3;
            }
        }
        return isset($map[(int) $term_id]) ? $map[(int) $term_id] : 0;
    }

    public static function category_colors()
    {
        $ids = get_terms(array('taxonomy' => 'category', 'hide_empty' => false, 'fields' => 'ids'));
        if (!is_array($ids) || !$ids) {
            return;
        }
        $css = '';
        foreach ($ids as $id) {
            $c = self::CAT_COLORS[self::category_color_index($id)];
            $css .= '.p-cat-item.p-cat-' . (int) $id . '{background:' . $c[0] . ';color:#fff}';
        }
        echo '<style id="kurabe-cat-colors">' . $css . "</style>\n";
    }

    /* re:Diver はカテゴリの説明文は meta description に出すが、タグ（店名）では何も出さない。
       タグの説明文を同じ形で出す（2026-10-01 店名タグにSEO説明文を入れたため） */
    public static function tag_meta_description()
    {
        if (!is_tag()) {
            return;
        }
        $d = trim(wp_strip_all_tags(term_description()));
        if ($d !== '') {
            echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
        }
    }

    /* 「検索エンジンがサイトをインデックスしないようにする」がオンの間は、全ページに noindex を付ける。
       re:Diver は記事ごとの設定（既定 noindex=false）でサイト全体の設定を上書きし、
       公開前なのに robots が「nofollow」だけになっていた（2026-09-30 実測）。
       公開時にこの設定をオフにすれば、ここは何もしなくなる */
    public static function robots_while_private($robots)
    {
        if ((string) get_option('blog_public') === '0') {
            $robots['noindex']  = true;
            $robots['nofollow'] = true;
        }
        // 記事（比較表）は掲載件数にかかわらず全部インデックスさせる（2026-10-29 吉村さん指示）。
        // 1.7.2 で入れた「掲載10件未満は noindex」は廃止。記事を noindex にする規則をここに足さない
        return $robots;
    }

    /* 新版の即時適用の窓口（管理者のアプリケーションパスワードで叩く）:
       POST /wp-json/kdb/v1/selfupdate → 更新キャッシュを捨てて配信元を確認し、
       WP標準の自動更新をその場で走らせる。通常の自動更新は半日周期のため、
       リリース直後に反映されない（スーツくらべ skdb/v1/selfupdate と同じ作り） */
    public static function rest_selfupdate()
    {
        // 指定した記事だけ、オートインサーター（affiros-auto-inserter）の商品取得・挿入を走らせる（2026-10-29 サンプル3本用）。
        // キーワードは先に postmeta _affiros_ai_keyword に入れておく。本文に [affiros_ai_card] があれば商品データの更新だけになる
        register_rest_route('kdb/v1', '/affiros-run', array(
            'methods'             => 'POST',
            'permission_callback' => function () {
                return current_user_can('edit_posts');
            },
            'callback'            => function ($req) {
                if (!class_exists('Affiros_AI_Inserter')) {
                    return new WP_Error('no_inserter', 'オートインサーターが有効になっていません', array('status' => 400));
                }
                $out = array();
                foreach (array_slice((array) $req->get_param('ids'), 0, 10) as $id) {
                    $r = Affiros_AI_Inserter::process(intval($id), array('force_refresh_products' => (bool) $req->get_param('refresh')));
                    $out[intval($id)] = $r;
                }
                return $out;
            },
        ));
        register_rest_route('kdb/v1', '/selfupdate', array(
            'methods'             => 'POST',
            'permission_callback' => function () {
                return current_user_can('update_plugins');
            },
            'callback'            => function () {
                $before = self::VERSION;
                delete_transient('kurabe_db_updater_' . md5(plugin_basename(__FILE__)));
                $active_before = (array) get_option('active_plugins', array());
                delete_site_transient('update_plugins');
                wp_update_plugins();
                if (function_exists('wp_maybe_auto_update')) {
                    wp_maybe_auto_update();
                }
                /* 自動更新はこのプラグイン以外（Re:Diverヘルパー等）も更新し、更新中に無効にしたまま戻さないことがある
                   （2026-10-15 ヘルパー 1.4.0 で100均・カタログとも無効のまま残った）。更新前に有効だったものを有効の一覧へ戻す */
                $restored = array();
                $now      = (array) get_option('active_plugins', array());
                foreach ($active_before as $p) {
                    if (!in_array($p, $now, true) && file_exists(WP_PLUGIN_DIR . '/' . $p)) {
                        $now[]      = $p;
                        $restored[] = $p;
                    }
                }
                if ($restored) {
                    update_option('active_plugins', array_values(array_unique($now)));
                }
                /* 更新の途中でWPはプラグインを無効にし、自分自身を更新したリクエストでは有効に戻らない
                   （2026-09-30 1.2.1 で無効のまま残った）。新しいファイルを読み込まずに有効の一覧へ戻す */
                $base   = plugin_basename(__FILE__);
                $active = (array) get_option('active_plugins', array());
                $was    = in_array($base, $active, true);
                if (!$was) {
                    $active[] = $base;
                    update_option('active_plugins', array_values(array_unique($active)));
                }
                return array('ok' => true, 'version_before' => $before, 'reactivated' => !$was, 'restored' => $restored);
            },
        ));
    }

    /* 比較ページは「サイズ：幅広」で組む。re:Diverは幅広のとき記事横の縦並びボタン
       （シェア・コピー・保存・目次・印刷）を本文の上に積んで大きな空白を作るので、
       比較データのあるページでは出さない（シェアはタイトル欄に残る） */
    public static function side_items($items)
    {
        return is_singular() && get_post_meta(get_the_ID(), self::META, true) ? array() : $items;
    }

    /* 比較ページは「サイズ：幅広」＋タイトルは通常の見た目（吉村さん指定）。
       re:Diver は幅広のとき通常のタイトル欄を出さない（ビッグだけ出す）ので、
       表示のときだけタイトルの設定を「ビッグ」→「デフォルト」に読み替え、
       テーマと同じタイトル欄をここで出し直す */
    private static $reading_layout = false;

    public static function layout_title_normal($value, $object_id, $meta_key, $single)
    {
        if ($meta_key !== 'diver_single_layout' || is_admin() || self::$reading_layout) {
            return $value;
        }
        self::$reading_layout = true;
        $has  = get_post_meta($object_id, self::META, true);
        $meta = get_post_meta($object_id, 'diver_single_layout', true);
        self::$reading_layout = false;
        if (!$has || !is_array($meta) || !isset($meta['title']) || $meta['title'] !== 'big') {
            return $value;
        }
        $meta['title'] = 'default';
        return array($meta);
    }

    public static function full_width_header()
    {
        if (!is_singular()) {
            return;
        }
        $id = get_the_ID();
        if (!get_post_meta($id, self::META, true)) {
            return;
        }
        $meta = get_post_meta($id, 'diver_single_layout', true);
        if (!is_array($meta) || !isset($meta['size']) || $meta['size'] !== 'full' || (isset($meta['title']) && $meta['title'] === 'hide')) {
            return;
        }
        ob_start();
        do_action('diver_single_main_header', $id);
        $header = ob_get_clean();
        if ($header) {
            echo '<header class="article-header -inner-content alignfull has-gap-column:10 is-position-relative">' . $header . '</header>';
        }
    }

    /* ---------- データ ---------- */

    public static function register_meta()
    {
        foreach (array('post', 'page') as $type) {
            foreach (array('kurabe_item', 'kurabe_group', 'kurabe_parent', 'kurabe_count', 'kurabe_stores') as $k) {
                register_post_meta($type, $k, array(
                    'type'          => 'string',
                    'single'        => true,
                    'show_in_rest'  => true,
                    'auth_callback' => function () {
                        return current_user_can('edit_posts');
                    },
                ));
            }
            register_post_meta($type, self::META, array(
                'type'          => 'string',
                'single'        => true,
                'show_in_rest'  => true,
                'auth_callback' => function () {
                    return current_user_can('edit_posts');
                },
            ));
        }
    }

    private static function data($post_id = null)
    {
        $post_id = $post_id ? $post_id : get_the_ID();
        if (!$post_id) {
            return null;
        }
        $raw = get_post_meta($post_id, self::META, true);
        if (!$raw) {
            return null;
        }
        $d = json_decode($raw, true);
        return is_array($d) && !empty($d['rows']) ? $d : null;
    }

    /* ---------- アフィリエイトID ---------- */

    private static function ids()
    {
        $own = get_option(self::OPT, array());
        $af  = get_option('affiros_ai_settings', array());
        $amazon  = !empty($own['amazon_tag']) ? $own['amazon_tag'] : (isset($af['amazon_partner_tag']) ? $af['amazon_partner_tag'] : '');
        $rakuten = !empty($own['rakuten_id']) ? $own['rakuten_id'] : (isset($af['rakuten_affiliate_id']) ? $af['rakuten_affiliate_id'] : '');
        if (!$amazon) {
            $amazon = get_option('yyi_rinker_amazon_traccking_id', '');
        }
        if (!$rakuten) {
            $rakuten = get_option('yyi_rinker_rakuten_affiliate_id', '');
        }
        return array(trim((string) $amazon), trim((string) $rakuten));
    }

    private static function amazon_url($q)
    {
        list($tag) = self::ids();
        $u = 'https://www.amazon.co.jp/s?k=' . rawurlencode($q);
        return $tag ? $u . '&tag=' . rawurlencode($tag) : $u;
    }

    private static function rakuten_url($q)
    {
        list(, $id) = self::ids();
        $u = 'https://search.rakuten.co.jp/search/mall/' . rawurlencode($q) . '/';
        return $id ? 'https://hb.afl.rakuten.co.jp/hgc/' . $id . '/?pc=' . rawurlencode($u) : $u;
    }

    /* ---------- 表示 ---------- */

    public static function assets()
    {
        $url = plugin_dir_url(__FILE__) . 'assets/';
        wp_register_style('kurabe-db', $url . 'kurabe.css', array(), self::VERSION);
        wp_register_script('kurabe-db', $url . 'kurabe.js', array(), self::VERSION, true);
    }

    public static function shortcode($atts)
    {
        $a = shortcode_atts(array('part' => 'table'), $atts, 'kurabe');
        $d = self::data();
        if (!$d) {
            return '';
        }
        wp_enqueue_style('kurabe-db');
        wp_enqueue_script('kurabe-db');
        $fn = 'part_' . preg_replace('/[^a-z]/', '', $a['part']);
        if (!method_exists(__CLASS__, $fn)) {
            return '';
        }
        return self::$fn($d);
    }

    /* 絞り込みと縮尺図が使うデータ。本文中の <script> はサイトによって削られるため、
       表・図の要素の data 属性に持たせる */
    private static function data_attr($d)
    {
        return ' data-kurabe="' . esc_attr(wp_json_encode(self::client_data($d), JSON_UNESCAPED_UNICODE)) . '"';
    }

    private static function client_data($d)
    {
        $rows = array();
        foreach ($d['rows'] as $r) {
            $rows[] = array(
                's'  => isset($r['s']) ? $r['s'] : '',
                'p'  => isset($r['p']) ? $r['p'] : null,
                'd'  => isset($r['dims']) ? $r['dims'] : null,
                'rg' => isset($r['range']) ? $r['range'] : null,
            );
        }
        return array(
            'mode'  => isset($d['mode']) ? $d['mode'] : 'none',
            'item'  => isset($d['item']) ? $d['item'] : '',
            'dimNames' => isset($d['dim_names']) ? $d['dim_names'] : array(),
            'rows'  => $rows,
        );
    }

    public static function label($s)
    {
        return isset(self::LABELS[$s]) ? self::LABELS[$s] : $s;
    }

    private static function date_ja($ymd)
    {
        $t = strtotime($ymd);
        return $t ? date('Y年n月j日', $t) : esc_html($ymd);
    }

    private static function part_source($d)
    {
        $uniq = array();
        foreach ($d['rows'] as $r) {                 // 同じ商品（JAN）は1件として数える
            $uniq[!empty($r['jan']) ? $r['jan'] : $r['u']] = true;
        }
        $n = count($uniq);
        $stores = array();
        foreach (array_keys(self::STORES) as $s) {
            foreach ($d['rows'] as $r) {
                if ($r['s'] === $s) {
                    $stores[] = $s;
                    break;
                }
            }
        }
        $h  = '<dl class="kurabe-source" aria-label="データの出どころ">';
        $h .= '<div><dt>最終確認</dt><dd><time datetime="' . esc_attr($d['checked']) . '">' . esc_html(self::date_ja($d['checked'])) . '</time></dd></div>';
        $h .= '<div><dt>出典</dt><dd>' . esc_html(implode('・', $stores)) . 'の公式通販（' . $n . '種）</dd></div>';
        $h .= '<div><dt>照合</dt><dd>JANコード（商品のバーコード番号）で同じ商品を判定</dd></div>';
        $h .= '<div><dt>空欄</dt><dd>公式に記載のない項目は推測で埋めず「記載なし」と表示</dd></div>';
        $h .= '</dl>';
        return $h;
    }

    private static function part_stats($d)
    {
        if (empty($d['stats'])) {
            return '';
        }
        $main = $d['stats'][0];
        $rest = array_slice($d['stats'], 1);
        $per = array();                              // 店ごとの掲載数（同じ商品は各店で数える）
        foreach (array_keys(self::STORES) as $st) {
            $n = 0;
            foreach ($d['rows'] as $r) {
                if ($r['s'] === $st) {
                    $n++;
                }
            }
            if ($n) {
                $per[$st] = $n;
            }
        }
        $h  = '<div class="kurabe-stats"><div class="kurabe-stats-main">';
        $h .= '<div class="kurabe-k">' . esc_html($main['k']) . '</div>';
        $h .= '<div class="kurabe-v kurabe-v-main">' . esc_html($main['v']) . '<small>' . esc_html(isset($main['u']) ? $main['u'] : '') . '</small></div>';
        if ($per) {
            $h .= '<div class="kurabe-bar" aria-hidden="true">';
            foreach ($per as $st => $n) {
                $h .= '<span class="kurabe-bar-' . self::STORES[$st] . '" style="flex:' . (int) $n . '"></span>';
            }
            $h .= '</div><div class="kurabe-bar-legend">';
            foreach ($per as $st => $n) {
                $h .= '<span><b class="kurabe-t-' . self::STORES[$st] . '">' . esc_html(self::label($st)) . '</b> ' . (int) $n . '</span>';
            }
            $h .= '</div>';
            if (count($per) > 1 && array_sum($per) !== (int) $main['v']) {
                $h .= '<div class="kurabe-bar-note">店ごとの数は、同じ商品を各店で数えています。</div>';
            }
        }
        $h .= '</div><div class="kurabe-stats-rest">';
        foreach ($rest as $x) {
            $h .= '<div class="kurabe-stats-row"><span class="kurabe-k">' . esc_html($x['k']) . '</span><span class="kurabe-v">' . esc_html($x['v']) . '<small>' . esc_html(isset($x['u']) ? $x['u'] : '') . '</small></span></div>';
        }
        $h .= '</div></div>';
        return $h;
    }

    private static function part_table($d)
    {
        $mode  = isset($d['mode']) ? $d['mode'] : 'none';
        $cols  = isset($d['cols']) && is_array($d['cols']) ? $d['cols'] : array();
        $label = isset($d['size_label']) ? $d['size_label'] : 'サイズ（cm）';

        $stores = array();
        $prices = array();
        foreach ($d['rows'] as $r) {
            $stores[$r['s']] = true;
            if (isset($r['p']) && $r['p'] !== null) {
                $prices[(int) $r['p']] = true;
            }
        }
        ksort($prices);

        $h  = '<div class="kurabe-table" data-mode="' . esc_attr($mode) . '"' . self::data_attr($d) . '>';
        $h .= '<p class="kurabe-stamp">' . esc_html(self::date_ja($d['checked'])) . '時点で、ダイソーネットストア・Can★Doネットショップ・ワッツオンラインに掲載されている情報です。店頭の品ぞろえとは違う場合があります。商品写真は各社の公式ページでご覧ください。</p>';

        $h .= '<div class="kurabe-filters">';
        $h .= '<div class="kurabe-fgroup"><span class="kurabe-flabel">店</span><div class="kurabe-chips" data-filter="s">';
        foreach (array_keys(self::STORES) as $s) {
            if (isset($stores[$s])) {
                $h .= '<button type="button" class="kurabe-chip kurabe-chip-' . self::STORES[$s] . '" data-v="' . esc_attr($s) . '" aria-pressed="true">' . esc_html(self::label($s)) . '</button>';
            }
        }
        $h .= '</div></div>';
        if (count($prices) > 1) {
            $h .= '<div class="kurabe-fgroup"><span class="kurabe-flabel">価格</span><div class="kurabe-chips" data-filter="p">';
            foreach (array_keys($prices) as $p) {
                $h .= '<button type="button" class="kurabe-chip" data-v="' . esc_attr($p) . '" aria-pressed="true">' . esc_html($p) . '円</button>';
            }
            $h .= '</div></div>';
        }
        $fit = isset($d['fit']) ? $d['fit'] : null;
        if ($fit && !empty($fit['inputs'])) {
            $h .= '<div class="kurabe-fgroup"><span class="kurabe-flabel">' . esc_html($fit['label']) . '</span><div class="kurabe-fit">';
            foreach ($fit['inputs'] as $i => $name) {
                if ($i > 0) {
                    $h .= '<span class="kurabe-dim">×</span>';
                }
                $id = 'kurabe-fit-' . $i;
                $h .= '<label for="' . $id . '" class="kurabe-dim">' . esc_html($name) . '</label><input id="' . $id . '" data-i="' . $i . '" type="number" inputmode="decimal" min="0" step="0.5" placeholder="—">';
            }
            $h .= '<span class="kurabe-dim">' . esc_html($fit['unit']) . '</span></div></div>';
        }
        $h .= '</div>';

        $h .= '<p class="kurabe-count" aria-live="polite"><b>' . count($d['rows']) . '</b> 件を表示中</p>';
        $h .= '<div class="kurabe-tablebox"><table><thead><tr>';
        $h .= '<th scope="col">店</th><th scope="col">商品名</th>';
        if ($mode !== 'none') {
            $h .= '<th scope="col"><button type="button" data-sort="sz">' . esc_html($label) . '</button></th>';
        }
        $h .= '<th scope="col"><button type="button" data-sort="p">価格（税込）</button></th>';
        foreach ($cols as $key => $cl) {
            $sortable = !empty($cl['sort']);
            $h .= '<th scope="col">' . ($sortable ? '<button type="button" data-sort="' . esc_attr($key) . '">' . esc_html($cl['label']) . '</button>' : esc_html($cl['label'])) . '</th>';
        }
        $h .= '</tr></thead><tbody>';          // 公式ページへは商品名のリンクで飛ぶので「公式」列は置かない（吉村さん指定）

        foreach ($d['rows'] as $i => $r) {
            $attrs = ' data-i="' . $i . '" data-s="' . esc_attr($r['s']) . '" data-p="' . esc_attr(isset($r['p']) ? $r['p'] : '') . '"';
            $attrs .= ' data-sz="' . esc_attr(isset($r['sz']) ? $r['sz'] : '') . '"';
            foreach ($cols as $key => $cl) {
                if (!empty($cl['sort'])) {
                    $attrs .= ' data-' . esc_attr($key) . '="' . esc_attr(isset($r[$key . '_n']) ? $r[$key . '_n'] : '') . '"';
                }
            }
            $cls = isset(self::STORES[$r['s']]) ? self::STORES[$r['s']] : 'other';
            $h .= '<tr' . $attrs . '>';
            $h .= '<td class="kurabe-td-store"><span class="kurabe-store kurabe-' . $cls . '">' . esc_html(self::label($r['s'])) . '</span></td>';
            // 商品名から公式の商品ページへ（別タブ）。吉村さん指定
            $h .= '<td class="kurabe-td-name"><a class="kurabe-pname" href="' . esc_url($r['u']) . '" target="_blank" rel="noopener">' . esc_html($r['n']) . '</a>';
            if (!empty($r['same'])) {
                // JANコードは本文に出さず、マウスを乗せたときだけ出す（吉村さん指定）
                $h .= '<span class="kurabe-sub" title="JANコード ' . esc_attr($r['jan']) . '">' . esc_html(implode('・', array_map(array(__CLASS__, 'label'), $r['same']))) . 'でも同じ商品を販売</span>';
            }
            $h .= '</td>';
            if ($mode !== 'none') {
                $h .= '<td class="kurabe-num" data-label="' . esc_attr($label) . '">' . (!empty($r['size_txt']) ? esc_html($r['size_txt']) : '<span class="kurabe-dim">記載なし</span>') . '</td>';
            }
            $h .= '<td class="kurabe-num" data-label="価格（税込）">' . (isset($r['p']) && $r['p'] !== null ? '<span class="kurabe-price">' . esc_html($r['p']) . '円</span>' : '<span class="kurabe-dim">記載なし</span>') . '</td>';
            foreach ($cols as $key => $cl) {
                $v = isset($r[$key]) ? $r[$key] : '';
                $from = isset($r['from'][$key]) ? $r['from'][$key] : '';
                $h .= '<td class="' . (!empty($cl['sort']) ? 'kurabe-num' : 'kurabe-text') . '" data-label="' . esc_attr($cl['label']) . '">';
                $h .= $v !== '' && $v !== null ? esc_html($v) . ($from ? '<span class="kurabe-sub">' . esc_html($from) . 'の掲載値</span>' : '') : '<span class="kurabe-dim">記載なし</span>';
                $h .= '</td>';
            }
            $h .= '</tr>';
        }
        $h .= '</tbody></table></div>';
        $h .= '<p class="kurabe-empty" hidden>条件に合う商品がありません。条件をゆるめてみてください。</p>';
        $h .= '</div>';
        return $h;
    }

    private static function part_scale($d)
    {
        if (empty($d['mode']) || $d['mode'] === 'none') {
            return '';
        }
        if ($d['mode'] === 'range') {
            return self::range_guide($d);
        }
        $item = isset($d['item']) ? $d['item'] : '';
        return '<div class="kurabe-scale"' . self::data_attr($d) . '><div class="kurabe-scale-grid" role="img" aria-label="' . esc_attr($item) . 'のサイズを同じ縮尺で並べた図"></div><div class="kurabe-legend"></div></div>';
    }

    /* 伸縮する品目（突っ張り棒など）の早見表：取り付けたい幅ごとに、各社で何円から何種あるか */
    private static function range_guide($d)
    {
        $rows = array();
        $max = 0;
        foreach ($d['rows'] as $r) {
            if (empty($r['range']) || mb_strpos($r['n'], '縦') !== false) {
                continue;          // 床と天井の間に立てる縦型は横幅の比較に入れない
            }
            $rows[] = $r;
            $max = max($max, $r['range'][1]);
        }
        if (!$rows) {
            return '';
        }
        $steps = array_values(array_filter(array(10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 150, 170, 190, 200, 210, 220, 250, 300),
            function ($w) use ($max) { return $w <= $max; }));
        $stores = array();
        foreach (array_keys(self::STORES) as $s) {
            foreach ($rows as $r) {
                if ($r['s'] === $s) {
                    $stores[] = $s;
                    break;
                }
            }
        }
        $h  = '<div class="kurabe-guide"><table><thead><tr><th scope="col">取り付けたい幅</th>';
        foreach ($stores as $s) {
            $h .= '<th scope="col"><span class="kurabe-store kurabe-' . self::STORES[$s] . '">' . esc_html(self::label($s)) . '</span></th>';
        }
        $h .= '</tr></thead><tbody>';
        foreach ($steps as $w) {
            $h .= '<tr><th scope="row">' . $w . 'cm</th>';
            foreach ($stores as $s) {
                $hit = array_filter($rows, function ($r) use ($s, $w) {
                    return $r['s'] === $s && $r['range'][0] <= $w && $w <= $r['range'][1];
                });
                if (!$hit) {
                    $h .= '<td class="kurabe-dim">なし</td>';
                    continue;
                }
                $ps = array_map(function ($r) { return (int) $r['p']; }, $hit);
                $h .= '<td><b>' . min($ps) . '円</b>から<span class="kurabe-sub">' . count($hit) . '種</span></td>';
            }
            $h .= '</tr>';
        }
        $h .= '</tbody></table></div>';
        return $h;
    }

    /* 関連する品目のリンク（公開済みのページだけを拾う。公開が増えれば自動で増える）
       投稿メタ: kurabe_item＝品目名 / kurabe_group＝ダイソーの売り場の小分類 /
                 kurabe_parent＝親の品目名（「ワイヤーネット用フック」なら「ワイヤーネット」）/ kurabe_count＝掲載種数 */
    private static function linked_posts($key, $value, $exclude, $limit)
    {
        if ($value === '' || $value === null) {
            return array();
        }
        $status = array('publish');
        if (is_preview() && current_user_can('edit_posts')) {
            $status[] = 'draft';      // 下書きのプレビューでは下書き同士もつないで確認できるようにする
        }
        return get_posts(array(
            'post_type'        => 'post',
            'post_status'      => $status,
            'posts_per_page'   => $limit,
            'post__not_in'     => array((int) $exclude),
            'meta_key'         => $key,
            'meta_value'       => $value,
            'orderby'          => 'title',
            'order'            => 'ASC',
            'suppress_filters' => true,
        ));
    }

    private static function link_list($posts)
    {
        $h = '<ul class="kurabe-links">';
        foreach ($posts as $p) {
            $item  = get_post_meta($p->ID, 'kurabe_item', true);
            $count = get_post_meta($p->ID, 'kurabe_count', true);
            $h .= '<li><a href="' . esc_url(get_permalink($p)) . '">100均' . esc_html($item ? $item : get_the_title($p)) . '</a>'
                . ($count ? '<span>' . (int) $count . '種</span>' : '') . '</li>';
        }
        return $h . '</ul>';
    }

    private static function part_related($d)
    {
        $id     = get_the_ID();
        $item   = get_post_meta($id, 'kurabe_item', true);
        $group  = get_post_meta($id, 'kurabe_group', true);
        $parent = get_post_meta($id, 'kurabe_parent', true);

        $pair = array_merge(
            $parent ? self::linked_posts('kurabe_item', $parent, $id, 1) : array(),
            $item ? self::linked_posts('kurabe_parent', $item, $id, 8) : array()
        );
        $seen = wp_list_pluck($pair, 'ID');
        $same = array_values(array_filter(self::linked_posts('kurabe_group', $group, $id, 16), function ($p) use ($seen) {
            return !in_array($p->ID, $seen, true);
        }));
        if (!$pair && !$same) {
            return '';
        }
        $name = $item ? $item : (isset($d['item']) ? $d['item'] : '');
        $h = '<h3 class="wp-block-heading">100均' . esc_html($name) . 'とあわせて見たい比較</h3><div class="kurabe-related">';   // ページの最後に置く小見出し（吉村さん指定）
        if ($pair) {
            $h .= '<p class="kurabe-related-label">一緒に使うもの</p>' . self::link_list($pair);
        }
        if ($same) {
            $h .= '<p class="kurabe-related-label">同じ売り場のもの</p>' . self::link_list($same);
        }
        return $h . '</div>';
    }

    /* カテゴリー・店名タグの一覧ページ：品目×3社の掲載数の表（吉村さん案A）
       公開済みの比較ページだけを拾う。店名タグのページはその店の掲載数の多い順 */
    public static function archive_table()
    {
        if (!(is_category() || is_tag()) || is_paged()) {
            return;
        }
        $term = get_queried_object();
        if (!$term || empty($term->term_id)) {
            return;
        }
        echo self::list_html(array('taxonomy' => $term->taxonomy, 'term' => $term->term_id));
    }

    public static function list_shortcode($atts)
    {
        $a = shortcode_atts(array('category' => '', 'tag' => ''), $atts, 'kurabe_list');
        if ($a['tag']) {
            $t = get_term_by('slug', $a['tag'], 'post_tag');
        } else {
            $t = get_term_by('slug', $a['category'], 'category');
        }
        return $t ? self::list_html(array('taxonomy' => $t->taxonomy, 'term' => $t->term_id)) : '';
    }

    /* ---------- TOPページの部品 [kurabe_top part="stats|genres|stores"] ----------
       公開済みの品目ページだけを数える。編集できる人がプレビューで見るときだけ下書きも含める */

    private static function top_posts()
    {
        $status = current_user_can('edit_posts') ? array('publish', 'draft', 'pending', 'future') : array('publish');
        return get_posts(array(
            'post_type'        => 'post',
            'post_status'      => $status,
            'posts_per_page'   => -1,
            'meta_key'         => 'kurabe_item',
            'suppress_filters' => true,
        ));
    }

    public static function top_shortcode($atts)
    {
        $a = shortcode_atts(array('part' => 'genres', 'max' => 10, 'item' => '突っ張り棒', 'tabs' => ''), $atts, 'kurabe_top');
        $posts = self::top_posts();
        if (!$posts) {
            return '';
        }
        wp_enqueue_style('kurabe-db');
        if ($a['part'] === 'stats') {
            return self::top_stats($posts);
        }
        if ($a['part'] === 'showcase') {
            return self::top_showcase($posts, $a['item']);
        }
        if ($a['part'] === 'sidebox') {
            return self::top_sidebox($posts);
        }
        if ($a['part'] === 'season') {
            wp_enqueue_script('kurabe-db');
            return self::top_season($posts, (string) $a['tabs']);
        }
        if ($a['part'] === 'stores') {
            return self::top_stores($posts);
        }
        return self::top_genres($posts, max(1, (int) $a['max']));
    }

    private static function top_stats($posts)
    {
        // 2つの比較表に同じ商品が載ることがある（2026-09-30 実測で228商品）。JANコード（無ければ商品URL）で重複を除いて数える
        $seen = array();
        foreach ($posts as $p) {
            $d = json_decode((string) get_post_meta($p->ID, self::META, true), true);
            foreach ((is_array($d) && !empty($d['rows'])) ? $d['rows'] : array() as $r) {
                $seen[!empty($r['jan']) ? $r['jan'] : (isset($r['u']) ? $r['u'] : '')] = 1;
            }
        }
        unset($seen['']);
        $goods = count($seen);
        // 語の途中で折り返さないよう短く1行に収める（「比べてい／ます」と割れた・2026-09-30）
        // 数字は「何商品を載せているか」だけにする（吉村さん指定 2026-09-30）
        return '<p class="kurabe-top-stats"><b>' . number_format($goods) . '</b>商品を掲載</p>';
    }

    /* TOPのジャンル見出しの頭に付ける線のアイコン（吉村さん 2026-10-01「くっきりした下線やめて、アイコンとかにできる？」）
       ジャンル名で引く。無いジャンルは値札のアイコン */
    private static function genre_icon($name, $term_id = 0)
    {
        $I = array(
            '文具'                     => '<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>',
            'バッグ・服飾雑貨'         => '<path d="M5 8h14l-1 12H6z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
            '電気'                     => '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
            'キッチン用品'             => '<path d="M4 10h16v3a6 6 0 0 1-6 6h-4a6 6 0 0 1-6-6z"/><path d="M2 10h2M20 10h2M9 4v3M12 4v3M15 4v3"/>',
            '化粧・ヘアケア'           => '<path d="M9 21h6v-9H9z"/><path d="M10 12V7l4-3v8"/>',
            'ハンドメイド'             => '<circle cx="6" cy="7" r="3"/><circle cx="6" cy="17" r="3"/><path d="M8.5 8.5L20 19M8.5 15.5L20 5"/>',
            '衛生・オーラル・バス用品' => '<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z"/>',
            '行楽・レジャー'           => '<path d="M3 20L12 4l9 16z"/><path d="M9 20l3-6 3 6"/>',
            '玩具・パーティー・スポーツ' => '<circle cx="12" cy="9" r="6"/><path d="M12 15l-1.5 2h3zM12 17c0 2-2 2-2 4"/>',
            '収納'                     => '<path d="M4 5h16v14H4zM4 12h16M10 8.5h4M10 15.5h4"/>',
            '靴・トラベル・雨具'       => '<path d="M3 12a9 9 0 0 1 18 0z"/><path d="M12 12v6a2 2 0 0 0 4 0"/>',
            'リフォーム'               => '<path d="M3 21l9-9"/><path d="M10 6l4-3 7 7-3 4-3-3-2 2-3-3 2-2z"/>',
            '工具・車・自転車'         => '<path d="M15 4a4 4 0 0 0-1 5l-9 9 2 2 9-9a4 4 0 0 0 5-1l-3-1-1-3z"/>',
            'リビング'                 => '<path d="M4 11V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3"/><path d="M2 11h20v6H2zM5 17v2M19 17v2"/>',
            '掃除'                     => '<path d="M9 3h4v4H9zM8 7h6l1 14H7zM13 4h3"/>',
            '衣料品'                   => '<path d="M8 3L3 6l2 4 3-1v12h8V9l3 1 2-4-5-3c0 2-2 3-4 3S8 5 8 3z"/>',
            'インテリア'               => '<path d="M12 21v-8M7 21h10"/><path d="M12 13c-4 0-6-3-6-7 4 0 6 3 6 7zM12 11c0-4 2-6 6-6 0 4-2 6-6 6z"/>',
            'キッチン消耗・日用品'     => '<rect x="5" y="4" width="10" height="16" rx="2"/><path d="M15 8h4v12h-4"/>',
            '食器・テーブルウェア'     => '<path d="M5 8h12v5a6 6 0 0 1-12 0z"/><path d="M17 9h2a2 2 0 0 1 0 4h-2M4 21h14"/>',
            '園芸・ペット'             => '<path d="M7 14h10l-1 7H8zM12 14V9"/><path d="M12 9c0-3 2-5 5-5 0 3-2 5-5 5zM12 11c0-2-2-4-4-4 0 2 2 4 4 4z"/>',
            'ギフト'                   => '<path d="M4 9h16v4H4zM5 13h14v8H5zM12 9v12"/><path d="M12 9C10 5 6 5 6 8s6 1 6 1zM12 9c2-4 6-4 6-1s-6 1-6 1z"/>',
            '洗濯'                     => '<path d="M10 5a2 2 0 1 1 2 2v1L3 15h18l-9-7"/>',
        );
        $p = isset($I[$name]) ? $I[$name] : '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="7.5" r="1.5"/>';
        $c = self::CAT_COLORS[self::category_color_index($term_id)];   // カードのカテゴリラベルと同じ色
        return '<span class="kurabe-genre-ico" aria-hidden="true" style="color:' . $c[0] . ';background:' . $c[1] . '"><svg viewBox="0 0 24 24">' . $p . '</svg></span>';
    }

    /* サイドバーの「サイトの強み」の箱（PR TIMES のサイドバーの「9,000万PV/月」の箱の形・吉村さん 2026-10-01）
       商品数は公開済みの比較表から重複を除いて数える */
    private static function top_sidebox($posts)
    {
        $seen = array();
        foreach ($posts as $p) {
            if ($p->post_status !== 'publish') {
                continue;
            }
            $d = json_decode((string) get_post_meta($p->ID, self::META, true), true);
            foreach ((is_array($d) && !empty($d['rows'])) ? $d['rows'] : array() as $r) {
                $seen[!empty($r['jan']) ? $r['jan'] : (isset($r['u']) ? $r['u'] : '')] = 1;
            }
        }
        unset($seen['']);
        $ico = array(
            'box'   => '<path d="M4 8l8-4 8 4v9l-8 4-8-4z"/><path d="M4 8l8 4 8-4M12 12v9"/>',
            'shop'  => '<path d="M3 9h18l-1.5-5h-15z"/><path d="M5 9v11h14V9M10 20v-6h4v6"/>',
            'code'  => '<path d="M4 5v14M7 5v14M10 5v14M14 5v14M16 5v14M20 5v14"/>',
            'check' => '<path d="M6 3h9l4 4v14H6z"/><path d="M9 13l2 2 4-4"/>',
        );
        $rows = array(
            array('box', '公式通販から集めた', number_format(count($seen)) . '商品'),
            array('shop', 'ダイソー・キャンドゥ・ワッツ', '3社を横並び'),
            array('code', '同じ商品はバーコードで', 'JANで照合'),
            array('check', '公式に無い値は', '推測しない'),
        );
        $logo = wp_get_attachment_image_url((int) get_theme_mod('custom_logo'), 'medium');
        $h  = '<div class="kurabe-sidebox"><p class="kurabe-sidebox-lead">100均3社を公式データで比べる</p>';
        $h .= $logo ? '<p class="kurabe-sidebox-logo"><img src="' . esc_url($logo) . '" alt="100均くらべ" width="220" height="55" loading="lazy"></p>' : '';
        foreach ($rows as $r) {
            // お店の行は店名を各社の色ラベルで出す（吉村さん 2026-10-01「ここラベルにしたら？」）
            $sub = $r[0] === 'shop'
                ? '<span class="kurabe-sidebox-labels"><i class="kurabe-store kurabe-daiso">DAISO</i><i class="kurabe-store kurabe-cando">Can★Do</i><i class="kurabe-store kurabe-watts">Watts</i></span>'
                : '<span>' . esc_html($r[1]) . '</span>';
            $h .= '<div class="kurabe-sidebox-row"><svg viewBox="0 0 24 24" aria-hidden="true">' . $ico[$r[0]] . '</svg><div>' . $sub . '<b>' . esc_html($r[2]) . '</b></div></div>';
        }
        // 箱の締めは検索窓（吉村さん 2026-10-01「データの集め方に遷移させてもなんも意味ない」）
        $h .= '<p class="kurabe-sidebox-q">探したい物の名前で比べる</p>'
            . '<form class="kurabe-sidebox-search" role="search" method="get" action="' . esc_url(home_url('/')) . '">'
            . '<input type="search" name="s" placeholder="例：突っ張り棒" aria-label="サイト内検索">'
            . '<button type="submit">検索</button></form></div>';
        return $h;
    }

    /* TOPの見本：1品目を3社の色の棒で比べる。物差しは品目の形で選ぶ
       （伸縮＝いちばん長く伸びる長さ／平面・立体＝いちばん長い辺／それ以外＝掲載数） */
    private static function top_showcase($posts, $item)
    {
        $post = null;
        foreach ($posts as $p) {
            if (get_post_meta($p->ID, 'kurabe_item', true) === $item) {
                $post = $p;
                break;
            }
        }
        if (!$post) {
            return '';
        }
        $d = json_decode((string) get_post_meta($post->ID, self::META, true), true);
        if (!is_array($d) || empty($d['rows'])) {
            return '';
        }
        $mode = isset($d['mode']) ? $d['mode'] : 'none';
        $val = array();
        $cnt = array();
        foreach ($d['rows'] as $r) {
            $s = $r['s'];
            $cnt[$s] = (isset($cnt[$s]) ? $cnt[$s] : 0) + 1;
            $v = 0;
            // 床と天井の間に立てる縦型は、記事の数字欄と同じく「横に渡せる幅」から外す（build_data.py と同じ決まり）
            if ($mode === 'range' && !empty($r['range']) && mb_strpos($r['n'], '縦') === false) {
                $v = (float) max($r['range']);
            } elseif (($mode === '2d' || $mode === '3d') && !empty($r['dims'])) {
                $v = (float) max($r['dims']);
            }
            if ($v > (isset($val[$s]) ? $val[$s] : 0)) {
                $val[$s] = $v;
            }
        }
        if ($val) {
            $what = $mode === 'range' ? 'いちばん長く伸びる長さ' : 'いちばん長い辺';
            $unit = 'cm';
        } else {
            $val = $cnt;
            $what = '公式通販の掲載数';
            $unit = '種';
        }
        $top = max($val);
        $h = '<div class="kurabe-showcase"><p class="kurabe-showcase-head">例：100均の' . esc_html($item) . '　<span>' . esc_html($what) . '</span></p>';
        foreach (self::STORES as $st => $cls) {
            if (!isset($val[$st])) {
                continue;
            }
            $w = $top ? max(8, round($val[$st] / $top * 100)) : 0;
            $num = rtrim(rtrim(number_format($val[$st], 1, '.', ''), '0'), '.');
            $h .= '<div class="kurabe-showcase-row"><span class="kurabe-showcase-store kurabe-t-' . $cls . '">' . esc_html(self::label($st)) . '</span>'
                . '<span class="kurabe-showcase-bar"><i class="kurabe-bar-' . $cls . '" style="width:' . $w . '%"></i></span>'
                . '<span class="kurabe-showcase-v">' . esc_html($num) . '<small>' . $unit . '</small></span></div>';
        }
        $h .= '<a class="kurabe-showcase-go" href="' . esc_url(get_permalink($post)) . '">100均' . esc_html($item) . 'の' . count($d['rows']) . '件を1枚の表で見る</a></div>';
        return $h;
    }

    private static function top_genres($posts, $max)
    {
        $by = array();
        foreach ($posts as $p) {
            $cats = get_the_category($p->ID);
            if (!$cats) {
                continue;
            }
            $c = $cats[0];
            if (!isset($by[$c->term_id])) {
                $by[$c->term_id] = array('term' => $c, 'rows' => array());
            }
            $by[$c->term_id]['rows'][] = array(
                'url'   => get_permalink($p),
                'item'  => get_post_meta($p->ID, 'kurabe_item', true),
                'total' => (int) get_post_meta($p->ID, 'kurabe_count', true),
            );
        }
        uasort($by, function ($x, $y) {
            return count($y['rows']) - count($x['rows']);
        });
        $h = '<div class="kurabe-genres">';
        foreach ($by as $g) {
            usort($g['rows'], function ($x, $y) {
                return $y['total'] - $x['total'];
            });
            $link = get_term_link($g['term']);
            $n = count($g['rows']);
            // 1ジャンルずつ re:Diver のコンテナ（dbp/container と同じ出力）で囲む（吉村さん指定 2026-09-30）
            $h .= '<section class="kurabe-genre wp-block-dbp-container padding-block:30 padding-inline:30 dbp-container">'
                . '<div class="dbp-container__inner"><h3 class="kurabe-genre-name">' . self::genre_icon($g['term']->name, $g['term']->term_id)
                . '<a href="' . esc_url($link) . '">' . esc_html($g['term']->name) . '</a></h3><ul>';
            foreach (array_slice($g['rows'], 0, $max) as $r) {
                $h .= '<li><a href="' . esc_url($r['url']) . '">' . esc_html($r['item']) . '</a><span>' . $r['total'] . '種</span></li>';
            }
            $h .= '</ul>';
            if ($n > $max) {
                $h .= '<a class="kurabe-genre-more" href="' . esc_url($link) . '">' . esc_html($g['term']->name) . 'をすべて見る</a>';
            }
            $h .= '</div></section>';
        }
        return $h . '</div>';
    }

    /* 旬の100均（PR TIMES の「旬速」の形・吉村さん案 2026-10-01）
       tabs="寒さ対策=ネックウォーマー,耳当て|ハロウィン=ろうそく,紙皿" の形で、タブ名と品目名を並べる。
       公開済みの比較表だけをカードにする（品目が未公開ならそのカードは出ない・空のタブは出さない） */
    private static function top_season($posts, $spec)
    {
        $by = array();
        foreach ($posts as $p) {
            $by[get_post_meta($p->ID, 'kurabe_item', true)] = $p;
        }
        $tabs = array();
        foreach (array_filter(array_map('trim', explode('|', $spec))) as $chunk) {
            $kv = explode('=', $chunk, 2);
            if (count($kv) < 2) {
                continue;
            }
            $cards = array();
            foreach (array_filter(array_map('trim', explode(',', $kv[1]))) as $item) {
                if (!isset($by[$item])) {
                    continue;
                }
                $p   = $by[$item];
                $per = json_decode((string) get_post_meta($p->ID, 'kurabe_stores', true), true);
                $cards[] = array('item' => $item, 'url' => get_permalink($p), 'total' => (int) get_post_meta($p->ID, 'kurabe_count', true),
                                 'per' => is_array($per) ? $per : array());
            }
            if ($cards) {
                $tabs[] = array('name' => trim($kv[0]), 'cards' => $cards);
            }
        }
        if (!$tabs) {
            return '';
        }
        $h = '<div class="kurabe-season"><div class="kurabe-season-tabs" role="tablist">';
        foreach ($tabs as $i => $t) {
            $h .= '<button type="button" class="kurabe-season-tab" role="tab" aria-selected="' . ($i ? 'false' : 'true') . '" aria-controls="kurabe-season-' . $i . '">'
                . esc_html($t['name']) . '</button>';
        }
        $h .= '</div>';
        foreach ($tabs as $i => $t) {
            $h .= '<div class="kurabe-season-panel" role="tabpanel" id="kurabe-season-' . $i . '"' . ($i ? ' hidden' : '') . '>';
            foreach ($t['cards'] as $c) {
                // B案：店名ラベルを上に、品名、「3社で◯種を比較 →」（吉村さん 2026-10-01「ごてごてしすぎ。Bにしよう」）
                $h .= '<a class="kurabe-season-card" href="' . esc_url($c['url']) . '"><span class="kurabe-season-stores">';
                foreach (self::STORES as $st => $cls) {
                    $n = isset($c['per'][$st]) ? (int) $c['per'][$st] : 0;
                    $h .= '<span class="kurabe-season-st ' . ($n ? 'kurabe-bar-' . $cls : 'is-none') . '">' . esc_html(self::label($st)) . ' ' . ($n ? $n : '—') . '</span>';
                }
                $h .= '</span><span class="kurabe-season-name">100均の' . esc_html($c['item']) . '</span>'
                    . '<span class="kurabe-season-go">3社で' . $c['total'] . '種を比較</span></a>';
            }
            $h .= '</div>';
        }
        return $h . '</div>';
    }

    private static function top_stores($posts)
    {
        $h = '<div class="kurabe-top-stores">';
        foreach (self::STORES as $st => $cls) {
            // その店の商品数（比較表をまたいだ重複はJANコードで除く）
            $seen = array();
            foreach ($posts as $p) {
                $d = json_decode((string) get_post_meta($p->ID, self::META, true), true);
                foreach ((is_array($d) && !empty($d['rows'])) ? $d['rows'] : array() as $r) {
                    if ($r['s'] === $st) {
                        $seen[!empty($r['jan']) ? $r['jan'] : (isset($r['u']) ? $r['u'] : '')] = 1;
                    }
                }
            }
            unset($seen['']);
            $n = number_format(count($seen));
            $term = get_term_by('slug', $cls, 'post_tag');
            $link = $term ? get_term_link($term) : '';
            $h .= '<a class="kurabe-top-store kurabe-top-store-' . $cls . '" href="' . esc_url(is_wp_error($link) ? '' : $link) . '">'
                . '<span class="kurabe-store kurabe-' . $cls . '">' . esc_html(self::label($st)) . '</span>'
                . '<span class="kurabe-top-store-n">' . $n . '<small>商品を掲載</small></span>'
                . '<span class="kurabe-top-store-go">' . esc_html(self::label($st)) . 'の比較表一覧へ</span></a>';
        }
        return $h . '</div>';
    }

    private static function list_html($q)
    {
        $posts = get_posts(array(
            'post_type'        => 'post',
            'post_status'      => 'publish',
            'posts_per_page'   => -1,
            'meta_key'         => 'kurabe_item',
            'tax_query'        => array(array('taxonomy' => $q['taxonomy'], 'field' => 'term_id', 'terms' => (int) $q['term'])),
            'suppress_filters' => true,
        ));
        if (!$posts) {
            return '';
        }
        $sort_store = '';
        if ($q['taxonomy'] === 'post_tag') {
            $slug = get_term((int) $q['term'])->slug;
            $sort_store = array_search($slug, self::STORES, true) ?: '';
        }
        $rows = array();
        foreach ($posts as $p) {
            $per = json_decode((string) get_post_meta($p->ID, 'kurabe_stores', true), true);
            $rows[] = array(
                'url'   => get_permalink($p),
                'item'  => get_post_meta($p->ID, 'kurabe_item', true),
                'total' => (int) get_post_meta($p->ID, 'kurabe_count', true),
                'per'   => is_array($per) ? $per : array(),
            );
        }
        usort($rows, function ($a, $b) use ($sort_store) {
            if ($sort_store) {
                $x = isset($a['per'][$sort_store]) ? $a['per'][$sort_store] : 0;
                $y = isset($b['per'][$sort_store]) ? $b['per'][$sort_store] : 0;
                if ($x !== $y) {
                    return $y - $x;
                }
            }
            return $b['total'] - $a['total'];
        });
        wp_enqueue_style('kurabe-db');
        $lead = $sort_store
            ? esc_html(self::label($sort_store)) . 'の公式通販に載っている商品の比較表を、' . esc_html(self::label($sort_store)) . 'の掲載数の多い順に並べています。'
            : 'ダイソー・キャンドゥ・ワッツの公式通販に載っている商品の比較表を、掲載数の多い順に並べています。';
        $h  = '<div class="kurabe-list"><p class="kurabe-list-lead">' . count($rows) . '件の比較表。' . $lead . '</p>';
        $h .= '<div class="kurabe-tablebox"><table><thead><tr><th scope="col">比較表</th>';
        foreach (self::STORES as $st => $cls) {
            $h .= '<th scope="col" class="kurabe-c"><span class="kurabe-store kurabe-' . $cls . '">' . esc_html(self::label($st)) . '</span></th>';
        }
        $h .= '<th scope="col" class="kurabe-c">合計</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $h .= '<tr><td><a href="' . esc_url($r['url']) . '">100均' . esc_html($r['item']) . '</a></td>';
            foreach (self::STORES as $st => $cls) {
                $n = isset($r['per'][$st]) ? (int) $r['per'][$st] : 0;
                $h .= '<td class="kurabe-c kurabe-num">' . ($n ? '<span class="kurabe-t-' . $cls . '">' . $n . '</span>' : '<span class="kurabe-none">—</span>') . '</td>';
            }
            $h .= '<td class="kurabe-c kurabe-num">' . $r['total'] . '種</td></tr>';
        }
        return $h . '</tbody></table></div></div>';
    }

    private static function part_shop($d)
    {
        if (empty($d['shop'])) {
            return '';
        }
        $item = isset($d['item']) ? $d['item'] : '';
        $h = '<div class="kurabe-shop" role="list">';
        foreach ($d['shop'] as $s) {
            $q = isset($s['q']) ? $s['q'] : $item;
            $h .= '<div class="kurabe-shop-row" role="listitem"><div class="kurabe-shop-cond"><b>' . esc_html($s['b']) . '</b>';
            if (!empty($s['note'])) {
                $h .= '<span>' . esc_html($s['note']) . '</span>';
            }
            $h .= '</div><div class="kurabe-shop-links">';
            $h .= '<a href="' . esc_url(self::amazon_url($q)) . '" target="_blank" rel="nofollow sponsored noopener">Amazonで探す</a>';
            $h .= '<a href="' . esc_url(self::rakuten_url($q)) . '" target="_blank" rel="nofollow sponsored noopener">楽天市場で探す</a>';
            $h .= '</div></div>';
        }
        $h .= '</div><p class="kurabe-adnote">上のリンクは広告（アフィリエイト）を含みます。価格と在庫はリンク先でご確認ください。</p>';
        return $h;
    }

    /* ---------- 設定画面 ---------- */

    public static function admin_menu()
    {
        add_options_page('100均くらべ 比較データ', '100均くらべ', 'manage_options', 'kurabe-db', array(__CLASS__, 'settings_page'));
    }

    public static function admin_init()
    {
        register_setting('kurabe_db', self::OPT, array(
            'type'              => 'array',
            'sanitize_callback' => function ($v) {
                return array(
                    'amazon_tag' => isset($v['amazon_tag']) ? sanitize_text_field($v['amazon_tag']) : '',
                    'rakuten_id' => isset($v['rakuten_id']) ? sanitize_text_field($v['rakuten_id']) : '',
                );
            },
        ));
    }

    public static function settings_page()
    {
        $o = get_option(self::OPT, array());
        list($amazon, $rakuten) = self::ids();
        echo '<div class="wrap"><h1>100均くらべ 比較データ</h1>';
        echo '<p>空欄のときはオートインサーター（またはRinker）の設定からIDを読みます。いま使われているID：Amazon <code>' . esc_html($amazon ? $amazon : '未設定') . '</code> ／ 楽天 <code>' . esc_html($rakuten ? '設定あり' : '未設定') . '</code></p>';
        echo '<form method="post" action="options.php">';
        settings_fields('kurabe_db');
        echo '<table class="form-table"><tr><th>AmazonトラッキングID</th><td><input class="regular-text" name="' . self::OPT . '[amazon_tag]" value="' . esc_attr(isset($o['amazon_tag']) ? $o['amazon_tag'] : '') . '"></td></tr>';
        echo '<tr><th>楽天アフィリエイトID</th><td><input class="regular-text" name="' . self::OPT . '[rakuten_id]" value="' . esc_attr(isset($o['rakuten_id']) ? $o['rakuten_id'] : '') . '"></td></tr></table>';
        submit_button();
        echo '</form></div>';
    }
}

Kurabe_Db::boot();
